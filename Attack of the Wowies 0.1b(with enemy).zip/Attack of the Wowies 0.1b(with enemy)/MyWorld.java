import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        super(1600, 900, 1);
        GreenfootImage bg = new GreenfootImage("dormroomlevel.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Character character = new Character();
        addObject(character,299,701);
        Door door = new Door();
        addObject(door,1238,736);
        Floor dormfloor = new Floor();
        addObject(dormfloor,752,898);
        removeObject(character);
        Floor dormfloor2 = new Floor();
        addObject(dormfloor2,280,726);
        removeObject(dormfloor2);
        Character character2 = new Character();
        addObject(character2,269,730);
        removeObject(character2);
        Character character3 = new Character();
        addObject(character3,762,695);
        removeObject(character3);
        Character character4 = new Character();
        addObject(character4,770,686);
        removeObject(character4);
        Character character5 = new Character();
        addObject(character5,763,689);
        character5.setLocation(320,673);
        character5.setLocation(296,673);
    }
}

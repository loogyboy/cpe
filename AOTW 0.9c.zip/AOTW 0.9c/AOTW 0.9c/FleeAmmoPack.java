import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FleeAmmoPack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FleeAmmoPack extends Powerups
{
    public FleeAmmoPack(int x, int y)
    {
        super(x, y);
    }
    
    public FleeAmmoPack()
    {
        super();
    }
    
    protected void checkHitCharacter()
    {
        if (!getObjectsInRange(100, Character.class).isEmpty())
        {
            Character chars = getObjectsInRange(100, Character.class).get(0);
            chars.addFleeAmmo();
            getWorld().removeObject(this);
        }
    } 
}

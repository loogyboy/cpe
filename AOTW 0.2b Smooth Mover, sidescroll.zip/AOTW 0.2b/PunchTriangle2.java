import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PunchTriangle2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PunchTriangle2 extends Actor
{
    /**
     * Act - do whatever the PunchTriangle2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public PunchTriangle2(){
        GreenfootImage image = getImage();  
        image.scale(150, 150);
        setImage(image);
    }
    public void act() 
    {
        hitTest();
    }
    public void hitTest(){
        if(this.getOneIntersectingObject(Enemy.class) != null){
            Enemy punching = (Enemy) this.getOneIntersectingObject(Enemy.class);
            punching.hitMelee();
        }
        getWorld().removeObject(this);
    }
}  


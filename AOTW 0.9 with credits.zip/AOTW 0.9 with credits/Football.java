import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Football here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Football extends Scrolling
{
    public int flyTimer = 50;
    public boolean facingLeft;
    /**
     * Act - do whatever the bottle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Football(){
        GreenfootImage image = getImage();  
        image.scale(75, 75);
    }

    public void act() 
    {
        flyTimer--;

        if(flyTimer >0 && facingLeft == false)
        {
            moveUpR();
        }
        if(flyTimer <= 0 && facingLeft == false)
        {
            moveDownR();
        }
        if(flyTimer <= 0 && facingLeft == true)
        {
            moveDownL();
        } 
        if(flyTimer >0 && facingLeft == true)
        {
            moveUpL();
        }
        hitPlayer();
    }    

    public void moveUpR()
    {
        setLocation(getX() +10 , getY()-1);
    }

    public void moveDownR()
    {
        setLocation(getX()+10 , getY()+1);
    }

    public void moveDownL()
    {
        setLocation(getX()-10 , getY()+1);
    }

    public void moveUpL()
    {
        setLocation(getX() -10 , getY()-1);
    }

    public void left()
    {
        facingLeft = true;
    }

    public void right()
    {
        facingLeft = false;
    }

    public void hitPlayer()
    {
        if (!getObjectsInRange(100, Character.class).isEmpty())
        {
            Character chars = getObjectsInRange(100, Character.class).get(0);
            chars.damage(1);
            getWorld().removeObject(this);
        }
    }    
}


import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RegAmmoPack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RegAmmoPack extends Powerups
{
    public RegAmmoPack(int x, int y)
    {
        super(x, y);
    }
    
    public RegAmmoPack()
    {
        super();
    }
    
    protected void checkHitCharacter()
    {
        if (!getObjectsInRange(100, Character.class).isEmpty())
        {
            Character chars = getObjectsInRange(100, Character.class).get(0);
            chars.addRegAmmo();
            getWorld().removeObject(this);
        }
    } 
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BakerBoss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BakerBoss extends Scroll
{

    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 800;
    private final static int WHeight1 = 450;
    public boolean bossDead;
    Scientist sci;
    private GreenfootSound bkgMusic;
   
    /**
     * Constructor for objects of class FratRowBoss.
     * 
     */
    public BakerBoss()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 800, 450, new GreenfootImage("CS4.png"));
        //prepare();

        prepare();
        bkgMusic = new GreenfootSound("Darkling.mp3");
        bkgMusic.playLoop();
    }
    public void act(){
        //checkBoss();
        cutscene5();
        setAmmoRem();
        testDead();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor5 = new Floor();
        addObject(floor5,392,447);

        character = new Character();
        addObject(character,600,330);

        GUI();
        health();

        sci = new Scientist();
        addObject(sci,216,331);
        character.spawnpoint = 4;
    }
    private void cutscene5(){
        if(sci.isDead == true){
            CS5 cs5 = new CS5();
            Greenfoot.setWorld(cs5);
            bkgMusic.stop();
        }
    }   
    private void testDead(){
        if(character.health <= 0){
            bkgMusic.stop();
        }
    }
}

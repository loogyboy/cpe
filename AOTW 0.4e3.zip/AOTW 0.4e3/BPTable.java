import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BPTable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BPTable extends Floor
{
    /**
     * Act - do whatever the BPTable wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public BPTable()
    {
        GreenfootImage image = getImage();  
        image.scale(300, 100);
        setImage(image);
    }
    public void act() 
    {
        
    }    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FratRow here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratRow extends Scroll
{
    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 3400;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class FratRow.
     * 
     */
    private int scale = 5;
    public FratRow()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 3400, 450, new GreenfootImage("FratRow.png"));
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,2504,449);
        Floor floor2 = new Floor();
        addObject(floor2,705,449);
        BPTable bptable = new BPTable();
        addObject(bptable,762,388);
        BPTable bptable2 = new BPTable();
        addObject(bptable2,2655,388);
        Window window = new Window();
        addObject(window,144,292);
        Window window2 = new Window();
        addObject(window2,457,290);
        Window window3 = new Window();
        addObject(window3,519,391);
        Window window4 = new Window();
        addObject(window4,104,396);
        Window window5 = new Window();
        addObject(window5,1087,301);
        Window window6 = new Window();
        addObject(window6,1304,296);
        Window window7 = new Window();
        addObject(window7,1534,297);
        Window window8 = new Window();
        addObject(window8,1541,414);
        Window window9 = new Window();
        addObject(window9,1076,412);
        Window window10 = new Window();
        addObject(window10,2031,291);
        Window window11 = new Window();
        addObject(window11,2033,397);
        Window window12 = new Window();
        addObject(window12,2434,287);
        Window window13 = new Window();
        addObject(window13,2435,397);
        Window window14 = new Window();
        addObject(window14,2848,272);
        Window window15 = new Window();
        addObject(window15,3030,270);
        Window window16 = new Window();
        addObject(window16,3211,270);
        Window window17 = new Window();
        addObject(window17,3022,386);
        Window window18 = new Window();
        addObject(window18,2855,386);
        character = new Character();
        addObject(character,189,327);
        
        //Powerups
        RegAmmoPack rap = new RegAmmoPack();
        addObject(rap, 650, 330);
        StunAmmoPack sap = new StunAmmoPack();
        addObject(sap, 750, 330);
        FleeAmmoPack fap = new FleeAmmoPack();
        addObject(fap, 850, 330);
        Gum gum = new Gum();
        addObject(gum, 2050, 400);
        HealthPackOne hpo = new HealthPackOne();
        addObject(hpo, 1300, 50);
        HealthPackTwo hpt = new HealthPackTwo();
        addObject(hpt, 2250, 50);
        DamageTrap dt = new DamageTrap();
        addObject(dt, 2950, 400);

        FratEnemy fratenemy = new FratEnemy();
        addObject(fratenemy,552,327);
        FratEnemy fratenemy2 = new FratEnemy();
        addObject(fratenemy2,600,327);
        FratEnemy fratenemy3 = new FratEnemy();
        addObject(fratenemy3,1000,327);
        FratEnemy fratenemy4 = new FratEnemy();
        addObject(fratenemy4,2552,327);
        
        /*Enemy enemy = new Enemy();
        addObject(enemy,1050,327);
        Enemy enemy2 = new Enemy();
        addObject(enemy2,950,327);
        Enemy enemy3 = new Enemy();
        addObject(enemy3,2800,327);
        Enemy enemy4 = new Enemy();
        addObject(enemy4,2700,327);
        Enemy enemy5 = new Enemy();
        addObject(enemy5,2600,327);
        */
        
        GUI();
        health();
    }
    public boolean stuff = false;
    public void Act()
    {
        if(stuff = false){
            Character accessVar = getObjects(Character.class).get(0);
            if(accessVar != null)
            {
                accessVar.image.scale(scale, scale);
                stuff = true;
                
            }
        }
    }
    
}

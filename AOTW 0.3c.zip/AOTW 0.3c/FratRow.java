import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FratRow here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratRow extends Scroll
{
    private final static int SWIDTH1 = 900;
    private final static int SHEIGHT1 = 600;
    private final static int WWIDTH1 = 5600;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class FratRow.
     * 
     */
    private int scale = 5;
    Actor character;
    public FratRow()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 3200, 600, new GreenfootImage("FratRow.png"));
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(365,275);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        floor.setLocation(780,448);
        BPTable bptable = new BPTable();
        addObject(bptable,694,385);
        removeObject(bptable);

        floor.setLocation(781,597);

        Floor floor2 = new Floor();
        addObject(floor2,2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2076,471);
        floor2.setLocation(2578,598);
        floor2.setLocation(2578,598);
        floor2.setLocation(2578,598);
        floor2.setLocation(2578,598);
        floor2.setLocation(2578,598);
        floor2.setLocation(2578,598);
        floor2.setLocation(2578,597);
        BPTable bptable2 = new BPTable();
        addObject(bptable2,645,356);
        removeObject(bptable2);
        BPTable bptable3 = new BPTable();
        addObject(bptable3,672,479);
        bptable3.setLocation(732,536);
        BPTable bptable4 = new BPTable();
        addObject(bptable4,1694,558);
        bptable4.setLocation(1690,543);
        BPTable bptable5 = new BPTable();
        addObject(bptable5,2481,533);
        bptable5.setLocation(2515,545);
        Window window = new Window();
        addObject(window,430,410);
        window.setLocation(430,385);
        Window window2 = new Window();
        addObject(window2,118,414);
        window2.setLocation(135,388);
        Window window3 = new Window();
        addObject(window3,110,524);
        window3.setLocation(97,527);
        window3.setLocation(99,527);
        Window window4 = new Window();
        addObject(window4,327,515);
        window4.setLocation(489,520);
        Window window5 = new Window();
        addObject(window5,1027,411);
        Window window6 = new Window();
        addObject(window6,1212,393);
        Window window7 = new Window();
        addObject(window7,1375,404);
        Window window8 = new Window();
        addObject(window8,1371,515);
        Window window9 = new Window();
        addObject(window9,1089,538);
        window5.setLocation(1024,398);
        window6.setLocation(1227,391);
        window7.setLocation(1445,395);
        window9.setLocation(1012,548);
        window8.setLocation(1452,551);
        Window window10 = new Window();
        addObject(window10,1904,398);
        Window window11 = new Window();
        addObject(window11,2314,406);
        Window window12 = new Window();
        addObject(window12,2307,530);
        Window window13 = new Window();
        addObject(window13,1896,521);
        window10.setLocation(1911,385);
        window13.setLocation(1911,529);
        window13.setLocation(1911,526);
        window11.setLocation(2293,382);
        window12.setLocation(2294,528);
        Window window14 = new Window();
        addObject(window14,2687,386);
        Window window15 = new Window();
        addObject(window15,2854,381);
        Window window16 = new Window();
        addObject(window16,2932,388);
        Window window17 = new Window();
        addObject(window17,2884,475);
        Window window18 = new Window();
        addObject(window18,2728,476);
        bptable5.setLocation(2496,545);
        window18.setLocation(2685,514);
        window14.setLocation(2680,358);
        window15.setLocation(2853,358);
        window17.setLocation(2844,513);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2932,388);
        window16.setLocation(2998,357);
        Character character = new Character();
        addObject(character,262,464);
    }
    public boolean stuff = false;
    public void Act()
    {
        if(stuff = false){
            Character accessVar = getObjects(Character.class).get(0);
            if(accessVar != null)
            {
                accessVar.image.scale(scale, scale);
                stuff = true;
                
            }
        }
    }
    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS3 extends World
{

    /**
     * Constructor for objects of class CS1.
     * 
     */
    GreenfootImage bg;
    Player player;
    Amy amy;
    private int cstimer = 0;
    public CS3()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("dormhallcs.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);

        player = new Player();
        addObject(player,600,330);

        amy = new Amy();
        addObject(amy,100,330);
    }

    public void act(){
        cstimer++;
        if(cstimer == 1){
            player.dirChange();
        }
        if(cstimer > 5 && cstimer < 175) {
            amy.amyTalking();
        }
        if(cstimer == 5) {
            Greenfoot.playSound("AmyCutScene3pt1.wav");
        }
        if(cstimer > 175 && cstimer < 405) {
           player.playerTalking();
        }
        if(cstimer == 175) {
            Greenfoot.playSound("PlayerCutscene3pt1.wav");
        }
        if(cstimer > 405 && cstimer < 800) {
            amy.amyTalking();
        }
        if(cstimer == 405) {
            Greenfoot.playSound("AmyCutScene3pt2.wav");
        }
        if(cstimer > 800 && cstimer < 1000) {
           player.playerTalking();
        }
        if(cstimer == 800) {
            Greenfoot.playSound("PlayerCutscene3pt2.wav");
        }
        if(cstimer > 1000 && cstimer < 1300) {
            amy.amyTalking();
        }
        if(cstimer == 1000) {
            Greenfoot.playSound("AmyCutScene3pt3.wav");
        }
        if(cstimer > 1300 && cstimer < 1400) {
           player.playerTalking();
        }
        if(cstimer == 1300) {
            Greenfoot.playSound("PlayerCutscene3pt3.wav");
        }
        if(cstimer > 1400 && cstimer < 1600) {
            amy.amyTalking();
        }
        if(cstimer == 1400) {
            Greenfoot.playSound("AmyCutScene3pt4.wav");
        }
        if(cstimer == 1650){
            Baker baker = new Baker();
            Greenfoot.setWorld(baker);
        }
    }
    
}

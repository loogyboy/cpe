import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FratBossAmmo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratBossAmmo extends Scrolling
{
    /**
     * Act - do whatever the FratBossAmmo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    /**
     * Act - do whatever the FratBossAmmo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public int speed = 10;
    public int timer = 200;
    public boolean facingLeft;
    
    public void act() 
    {
       timer--;
       
        
        if (timer > 0 && facingLeft == false)
        {
            setLocation(getX()+10, getY());
        }
        if (timer > 0 && facingLeft == true)
        {
            setLocation(getX()-10, getY());
        }
        disappear();
    } 
    
    public void disappear()
    {
        
        Character c = (Character) getOneIntersectingObject(Character.class);
        if(timer == 0)
        {
            getWorld().removeObject(this);
        }

        else if( c != null){
            c.damage(2);
            getWorld().removeObject(this);
        }
    }
    
    public void TurnLeft()
    {
        facingLeft = true;

    }

    public void TurnRight()
    {
        facingLeft = false;
    }

}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS1 extends World
{

    /**
     * Constructor for objects of class CS1.
     * 
     */
    GreenfootImage bg;
    Player player;
    Wowie wowie;
    Jim jim;
    private int cstimer = 0;
    public CS1()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("dormroomlevel.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);

        player = new Player();
        addObject(player,456,330);

        wowie = new Wowie();
        jim = new Jim();
        
    }

    public void act(){
        cstimer++;
        if(cstimer == 1){
            Greenfoot.playSound("knock.wav");
        }
        if(cstimer == 300){
            Greenfoot.playSound("door.wav");
        }
        if(cstimer == 400){
            bg = new GreenfootImage("dormroomlevelopendoor.png");
            bg.scale(getWidth(), getHeight());
            setBackground(bg);
            addObject(wowie,699,330);
        }
        if(cstimer == 450){
            Greenfoot.playSound("zombie.wav");
        }
        if(cstimer == 500){
            addObject(jim,633,330);
        }
        if(cstimer == 550){
            Greenfoot.playSound("punch.wav");
        }
        if(cstimer == 600){
            Greenfoot.playSound("wilhelm.wav");
            removeObject(wowie);
        }
        if(cstimer > 650 && cstimer < 850){
            jim.jimTalking();
        }
        if(cstimer > 850 && cstimer < 900){
            player.playerTalking();
        }
        if(cstimer == 900){
            addObject(wowie,699,330);
            Greenfoot.playSound("zombie.wav");
        }
        if(cstimer > 900 && cstimer < 1040){
            jim.jimTalking();
        }
        if(cstimer > 1000 && cstimer < 940){
            wowie.move(-1);
        }
        if(cstimer == 1030){
            Greenfoot.playSound("bite.wav");
        }
        if(cstimer == 1040){
            removeObject(wowie);
            jim.jimDeath();
            Greenfoot.playSound("eating.wav");
        }
        if(cstimer > 1040 && cstimer < 1100){
            jim.jimDying();
        }
        if(cstimer == 1100){
            Greenfoot.playSound("wilhelm.wav");
            addObject(wowie,660,330);
            removeObject(jim);
        }
        if(cstimer > 1100 && cstimer < 1150){
            player.playerTalking();
            player.move(2);
        }
        if(cstimer == 1150){
            Greenfoot.playSound("punch.wav");
        }
        if(cstimer == 1200){
            Greenfoot.playSound("wilhelm.wav");
            removeObject(wowie);
        }
        if(cstimer == 1350){
            DormHall dormHall = new DormHall();
            Greenfoot.setWorld(dormHall);
        }
    }
    
}

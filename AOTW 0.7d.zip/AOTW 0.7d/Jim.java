import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Wowie here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jim extends CutsceneActors
{
    /**
     * Act - do whatever the Wowie wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Jim(){
        image.scale(curscale, curscale);
        setImage(image);

    }
    public GreenfootImage image = getImage();
    private int pulsescale = 5;
    private int eatpulsescale = 2;
    private int normscale = 200;
    private int curscale = normscale;
    private int pulseTimer = 0;
    public void act() 
    {

    }

    public void jimDying(){
        pulseTimer++;
        if(pulseTimer < eatpulsescale){
            curscale++;
        }
        if(pulseTimer >= eatpulsescale && pulseTimer < 2*eatpulsescale){
            curscale--;
        }
        if(pulseTimer == 2*eatpulsescale){
            curscale = normscale;
            pulseTimer = 0;
        }
        image.scale(curscale, curscale);
        setImage(image);
    }
    public void jimTalking(){
        pulseTimer++;
        if(pulseTimer < pulsescale){
            curscale++;
        }
        if(pulseTimer >= pulsescale && pulseTimer < 2*pulsescale){
            curscale--;
        }
        if(pulseTimer == 2*pulsescale){
            curscale = normscale;
            pulseTimer = 0;
        }
        image.scale(curscale, curscale);
        setImage(image);
    }
    public void jimDeath(){
        setImage("jimmy5.png");
        image = this.getImage();
        image.scale(curscale, curscale);
        
    }
}

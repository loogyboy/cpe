import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class punchTriangle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PunchTriangle extends Scrolling
{
    /**
     * Act - do whatever the punchTriangle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public PunchTriangle(){
        GreenfootImage image = getImage();  
        image.scale(75, 75);
        setImage(image);
    }
    public void act() 
    {
        hitTest();
    }
    public void hitTest(){
        List<Enemy> list;
        list= getObjectsInRange(125, Enemy.class);
        if (list.isEmpty() == false)
        {
            Enemy punching = (Enemy) list.get(0);
            punching.hitMelee(1);
        }
        
        getWorld().removeObject(this);
    }
}

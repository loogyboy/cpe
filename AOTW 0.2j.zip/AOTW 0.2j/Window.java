import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Window here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Window extends Floor
{
    /**
     * Act - do whatever the Window wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Window()
    {
        GreenfootImage image = getImage();  
        image.scale(125,10);
        setImage(image);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS6 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS6 extends World
{
      /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    /**
     * Constructor for objects of class CS6.
     * 
     */
     GreenfootImage bg;
    Player player;
    Racs racs;
    private int cstimer = 0;
    public CS6()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("CS6.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

   

    public void act(){
        cstimer++;
     
        if(cstimer == 50){
            FratRowBoss fratrowboss = new FratRowBoss();
            Greenfoot.setWorld(fratrowboss);
        }
    }
    



 
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,427,448);
      
        
        BPTable bptable = new BPTable();
        addObject(bptable,116,352);
        bptable.setLocation(144,392);

        Window window = new Window();
        addObject(window,346,261);
        window.setLocation(330,269);
        Window window2 = new Window();
        addObject(window2,482,261);
        window2.setLocation(484,269);
        Window window3 = new Window();
        addObject(window3,612,274);
        window3.setLocation(637,271);
        Window window4 = new Window();
        addObject(window4,388,347);
        window4.setLocation(333,385);
        Window window5 = new Window();
        addObject(window5,439,360);
        window5.setLocation(480,385);
        player = new Player();
        addObject(player,600,330);

        FratBoss fratboss = new FratBoss();
        addObject(fratboss,0,330);
        
    }
}

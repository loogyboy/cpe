import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BakerOutside here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BakerOutside extends Scroll
{

    private final static int SWIDTH1 =800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 3400;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class Stadium.
     * 
     */
    private int scale = 5;
    //Character character;
    public BakerOutside()
    {    
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 3200, 450, new GreenfootImage("Baker Outside.png"));// Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        prepare();
    }

    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,375,465);
        Floor floor2 = new Floor();
        addObject(floor2,909,445);
        character = new Character();
        addObject(character,69,298);
        Floor floor3 = new Floor();
        addObject(floor3,1600,445);

        GUI();
        character.setLocation(72,316);
        character.setLocation(64,321);
    }
}

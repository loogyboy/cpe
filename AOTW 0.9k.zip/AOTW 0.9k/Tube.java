import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WriteUp here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tube extends Scrolling
{
    public boolean facingLeft;
    public int flyTimer = 50;
    public int scalingDamage = 1;
    /**
     * Act - do whatever the WriteUp wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Tube(){
        GreenfootImage image = getImage();  
        image.scale(50, 50);
    }

    public void act() 

    {
        turn(10);
        flyTimer--;
        if(flyTimer >0 && facingLeft == false)
        {
            moveUpR();
        }
        if(flyTimer <= 0 && facingLeft == false)
        {
            moveDownR();
        }
        if(flyTimer <= 0 && facingLeft == true)
        {
            moveDownL();
        } 
        if(flyTimer >0 && facingLeft == true)
        {
            moveUpL();
        }
        hitPlayer();
    }   

    public void moveUpR()
    {
        setLocation(getX() +7 , getY()-2);
    }

    public void moveDownR()
    {
        setLocation(getX()+7 , getY()+2);
    }

    public void moveDownL()
    {
        setLocation(getX()-7 , getY()+2);
    }

    public void moveUpL()
    {
        setLocation(getX() -7 , getY()-2);
    }

    public void left()
    {
        facingLeft = true;
    }

    public void right()
    {
        facingLeft = false;
    }

    public void hitPlayer()
    {

        Character c = (Character) getOneIntersectingObject(Character.class);
        if( c != null){
            c.RADamage(scalingDamage);
            getWorld().removeObject(this);
        }
    }

    public void scalingDamage1()
    {
        scalingDamage = 2;
    }

    public void scalingDamage2()
    {
        scalingDamage = 3;
    }
}
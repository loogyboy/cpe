import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Character here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Character extends Actor
{
    /**
     * Act - do whatever the Character wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Character(){
        GreenfootImage image = getImage();  
        image.scale(400, 400);
        setImage(image);
    }
    public void act() 
    {
        playerMovement();
    }
    public void playerMovement(){
        if(Greenfoot.isKeyDown("d")){
            setImage("mainguy1.png");
            GreenfootImage image = getImage();  
            image.scale(400, 400);
            move(5);
            setImage("mainguy2.png");
            image = getImage();
            image.scale(400, 400);
            move(5);
        }
        if(Greenfoot.isKeyDown("a")){
            setImage("mainguy3.png");
            GreenfootImage image = getImage();  
            image.scale(400, 400);
            move(-5);
            setImage("mainguy4.png");
            image = getImage();
            image.scale(400, 400);
            move(-5);
        }
    }
}

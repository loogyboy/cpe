import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Endgame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Endgame extends World
{

    /**
     * Constructor for objects of class Endgame.
     * 
     */
    public Endgame()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 450, 1,false); 
        prepare();
    }
    private GreenfootSound bkgMusic = new GreenfootSound("endcredits.mp3");
    int timer = 0;
    public void act(){
        timer++;
        if(timer == 1){
            bkgMusic.playLoop();
        }
        if(timer == 1620){
            bkgMusic.stop();
            TitleScreen ts = new TitleScreen();
            Greenfoot.setWorld(ts);
        }
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Credits credits = new Credits();
        addObject(credits,400,950);
        
    }
}

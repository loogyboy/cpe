import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS8 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS8 extends World
{

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    /**
     * Constructor for objects of class CS6.
     * 
     */
    GreenfootImage bg;
    Player player;
    Racs racs;
    private int cstimer = 0;
    public CS8()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("Spanos Stadium.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);

        prepare();
    }


    public void act(){
        cstimer++;

        if(cstimer == 50){
            StadiumBoss stadiumboss = new StadiumBoss();
            Greenfoot.setWorld(stadiumboss);
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(453,448);
    }
}

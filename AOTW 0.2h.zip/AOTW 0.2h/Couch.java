import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Couch here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Couch extends Floor
{
    /**
     * Act - do whatever the Couch wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Couch(){
        GreenfootImage image = getImage();  
        image.scale(740, 200);
        setImage(image);
    }
    public void act() 
    {
       
        
    }    
}

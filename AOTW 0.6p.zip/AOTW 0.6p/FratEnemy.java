import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class FratEnemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratEnemy extends EnemyBase
{

    private boolean onBackStep = false;
    private int canChange;
    public boolean facingLeft = false;

    private int walkTimer = 0; //Times onStepBack in order to switch images at even intervals
    private int weaponID = 0; //controls weapon type, 0 is bare hands
    private double movespeed = 2;
    private int speed;
    private int gravity = 1;
    private boolean jumping;
    private int timer;
    private boolean falling;
    private boolean infront;
    private boolean inbehind;
    private int direction = 80;
    private int jumpreset;
    private boolean jumpres;
    private boolean following = false;
    private int stunDelay = -1;
    private int fleeTimer = -1;

    public FratEnemy()
    {
        GreenfootImage image = getImage();  
        image.scale(200, 200);
        setImage(image);
        health=4;
        eSpeed=2;
        kockback=false;
        kTimer=0;
    }

    /**
     * Act - do whatever the FratEnemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (stunDelay < 0)
            {
                if (fleeTimer < 0)
                {
                    aimlessMove();
                    throwBottle();
                }
                else
                {
                    runAway();
                    fleeTimer--;
                }
            }
            else
            {
                stunDelay--;
            }
        checkFall();
        gravityjump();
        Knockback();
        enemyHit();
        
        death();
    }    

    public void throwBottle()
    {
        if(Greenfoot.getRandomNumber(1000) <5)
        {
            Bottle b = new Bottle();
            if(facingLeft ==true)
            {
                b.setRotation(225);
                b.left();
            }
            else
            {
                b.setRotation(325);
                b.right();
            }

            getWorld().addObject(b, getX(), getY());
        }
    }

     public void EnemyMovement()
    //moves the enemy in the diection it's facing (Luke Underwood)
    {
        World w = (World) getWorld();
        if (kockback == false){
            if (facingLeft == true && getX() > 5) 
            {
                move(-eSpeed);
                if(onBackStep == false){
                    //setImage("fratguy3.png");
                }
                if(onBackStep == true){
                    // setImage("fratguy4.png");
                }
                GreenfootImage image = getImage();  
                //image.scale(200, 200);
            }
            else if (facingLeft == false && getX() < w.getWidth())
            {
                move(eSpeed);
                if(onBackStep == false){
                    //setImage("fratguy1.png");
                }
                if(onBackStep == true){
                    //setImage("fratguy2.png");
                }
                //GreenfootImage image = getImage();  
                //image.scale(200, 200);
            }
        }
    }

    public void aimlessMove()
    {
        if (kockback == false){

            EnemyOrient();
            EnemyMovement();
        }
    }
    
    public void runAway()
    {
        if (kockback == false){
            if(following == true){
                if (Character.CharacterX < this.getX())
                {
                    if(onBackStep == false){
                        setImage("fratguy1.png");
                    }
                    if(onBackStep == true){
                        setImage("fratguy2.png");
                    }
                    GreenfootImage image = getImage();  
                    image.scale(200, 200);
                    facingLeft=true;
                    move(eSpeed);
                }
                if (Character.CharacterX > this.getX())
                {
                    if(onBackStep == false){
                        setImage("fratguy3.png");
                    }
                    if(onBackStep == true){
                        setImage("fratguy4.png");
                    }
                    GreenfootImage image = getImage();  
                    image.scale(200, 200);
                    facingLeft=false;
                    move(-eSpeed);
                }
                //turnTowards(Character.CharacterX, getY());
                //move(2);
            }

        }
        
    }

    private void EnemyOrient()
    //turns enemy right 50% of the time and left 50% of the time (Luke Underwood)
    {
        canChange = canChange + 1;
        if (canChange % 60 == 0)
        {
            if (Greenfoot.getRandomNumber (9) < 4)
            { 
                TurnLeft();
            }
            else {
                TurnRight();
            }

        }
    }

    public void TurnLeft()
    {
        facingLeft = true;

    }

    public void TurnRight()
    {
        facingLeft = false;
    }
    
    public void stun()
    {
        stunDelay = 50;
    }
    
    public void flee()
    {
        fleeTimer = 75;
    }

}

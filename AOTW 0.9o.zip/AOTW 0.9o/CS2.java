import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS2 extends World
{

    /**
     * Constructor for objects of class CS1.
     * 
     */
    GreenfootImage bg;
    Player player;
    Racs racs;
    private int cstimer = 0;
    public CS2()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("dormhallcs.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);

        player = new Player();
        addObject(player,600,330);

        racs = new Racs();
        addObject(racs,0,330);
    }

    public void act(){
        cstimer++;
        if(cstimer == 275){
            DormHallBoss dormHallb = new DormHallBoss();
            Greenfoot.setWorld(dormHallb);
        }
        if(cstimer > 5 && cstimer < 305){
            racs.talking();
        }
        if(cstimer == 5) {
            Greenfoot.playSound("RAvoice1.wav");

        }
    }
    
}

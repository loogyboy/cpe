import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS4 extends World
{
    GreenfootImage bg;
    Player player;
    Scics scics;
    private int cstimer = 0;
    public CS4()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("CS4.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,408,447);
        
        player = new Player();
        addObject(player,600,335);

        scics = new Scics();
        addObject(scics,126,313);
    }

      public void act(){
        cstimer++;
        if(cstimer > 20 && cstimer < 250)
        {
            scics.talking();
            
        }
        if(cstimer == 20)
        {
            Greenfoot.playSound("EvilScientist.wav");
        }
        if(cstimer == 270){
            BakerBoss bakerboss = new BakerBoss();
            Greenfoot.setWorld(bakerboss);
        }
    }
}


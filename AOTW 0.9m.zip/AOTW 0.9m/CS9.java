import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS9 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS9 extends World
{

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    /**
     * Constructor for objects of class CS6.
     * 
     */
    GreenfootImage bg;
    Player player;
    Scissors scissors;
    private int cstimer = 0;
    public CS9()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("Spanos Stadium.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);

        prepare();
    }

    public void act(){
        cstimer++;
        if(cstimer == 1){
            Greenfoot.playSound("PlayerCS91.wav");
        }
        if(cstimer > 1 && cstimer < 200){
            player.playerTalking();
        }
        if(cstimer == 300){
            addObject(scissors,500,355);
            Greenfoot.playSound("PlayerCS92.wav");            
        }
        if(cstimer > 300 && cstimer < 400){
            player.playerTalking();
        }
        if(cstimer > 400 && cstimer < 700){
            player.move(1);
        }

        if(cstimer == 700){
            removeObject(scissors);
            Greenfoot.playSound("PlayerNar.wav");
        }
        if(cstimer == 1500){
            Endgame endgame = new Endgame();
            Greenfoot.setWorld(endgame);
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,453,448);

        player = new Player();
        addObject(player,200,324);

        scissors = new Scissors();
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Stadium here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Stadium extends Scroll
{
    private final static int SWIDTH1 =800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 2500;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class Stadium.
     * 
     */
    private int scale = 5;
    //Character character;
    public Stadium()
    {    
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 2400, 450, new GreenfootImage("Spanos Stadium.png"));// Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        prepare();
        worldID = 3;
    }
    public void act(){
        //cutscene3();
        setAmmoRem();
    }

    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,375,445);
        Floor floor2 = new Floor();
        addObject(floor2,909,445);
        character = new Character();
        addObject(character,69,298);
        Floor floor3 = new Floor();
        addObject(floor3,1600,445);
        
        RegAmmoPack rap = new RegAmmoPack();
        addObject(rap, 350, 180);
        StunAmmoPack sap = new StunAmmoPack();
        addObject(sap, 675, 180);
        Gum gum = new Gum();
        addObject(gum, 1000, 400);
        FleeAmmoPack fap = new FleeAmmoPack();
        addObject(fap, 1430, 180);
        HealthPackOne hpo = new HealthPackOne();
        addObject(hpo, 1260, 280);
        HealthPackTwo hpt = new HealthPackTwo();
        addObject(hpt, 1850, 180);
        
        
        FootballEnemy footballenemy = new FootballEnemy();
        addObject(footballenemy,800,321);
        
        FootballEnemy footballenemy2 = new FootballEnemy();
        addObject(footballenemy2,1500,321);
        
        FootballEnemy footballenemy3 = new FootballEnemy();
        addObject(footballenemy3,2000,321);
        
        Quarterback q = new Quarterback();
        addObject(q, 1000, 321);
        
        Quarterback q2 = new Quarterback();
        addObject(q2, 1750, 321);
        
        health();
        GUI();
    }
    public int getID(){
        return worldID;
    }
    private void cutscene7(){
        if(character.loc > 2300){
            CS8 cs8 = new CS8();
            Greenfoot.setWorld(cs8);
        }
    }
}

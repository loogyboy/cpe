import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Character here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Character extends SmoothMover
{
    private int shotTimer = 0;
    /**
     * Act - do whatever the Character wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Character(){  
        image.scale(curscale, curscale);
        setImage(image);
    }
    int speedx = 1;
    int speedy = 1;
    public void act() 
    {
        move1 = getX();
        moveUtil();
        findDoor();
        CharacterX = getX();
        CharacterY = getY();
        combat();
        shooting();
       
        // Add your action code here.
        Knockback();
        move2 = getX();
        if(move2 != move1)
            change = move2 - move1;
        boundedMove();
         if(fireRes == true && shotTimer > 0)
        {
            shotTimer--;
        }
    }
        public boolean fireRes = true;
    private boolean onBackStep = false; //switches between images to control walking animation
    private int walkTimer = 0; //Times onStepBack in order to switch images at even intervals
    private int weaponID = 0; //controls weapon type, 0 is bare hands
    private double basespeed = 8;
    private double movespeed = basespeed;
    private double maxspeed = 16;
    private int speed;
    private int gravity = 1;
    private boolean jumping;
    private int timer;
    private boolean falling;
    private boolean infront;
    private boolean inbehind;
    private int direction = 40;
    private int jumpreset;
    private boolean jumpres;
    public boolean isTouchingDoor = false;
    public static int CharacterX, CharacterY;
    private int stunDelay = -1;
    private int speedTimer = -1;
    public GreenfootImage image = getImage();
    private int pulsescale = 3;
    private int normscale = 200;
    private int curscale = normscale;
    private int pulseTimer = 0;
    private boolean moving;
    private boolean moving2; 
    private static final int BOUNDARY = 400;
    private int move1 = 0;
    private int move2 = 0;
    public int change;
    private int bulletspeed = 30;
    public int worldID;
    private boolean atEdgeL = true;
    private boolean atEdgeR = false;
    private boolean atAnEdge;
    private static int regAmmo = 5;
    private static int stunAmmo = 0;
    private static int fleeAmmo = 0;
    private int xpos;

    public void fireBullet() {
        RubberbandBullet b = new RubberbandBullet();
        b.setRotation(getRotation());

        getWorld().addObject(b, getX(), getY());
        b.direction(bulletspeed);
    }

    public void fireStunBullet() {
        RubberbandStun rbs = new RubberbandStun();
        rbs.setRotation(getRotation());

        getWorld().addObject(rbs, getX(), getY());
        rbs.direction(bulletspeed);
    }

    public void fireFleeBullet()
    {
        RubberbandFlee rbf = new RubberbandFlee();
        rbf.setRotation(getRotation());

        getWorld().addObject(rbf, getX(), getY());
        rbf.direction(bulletspeed);
    }

    public void moveUtil(){
        sprint();        
        moveEffects();
        //playerMovement();
        dirChangeTest();
        //jump();
        image = getImage();
        image.scale(curscale, curscale);
        playerModel();
        playerPulse();
    }

    public void playerMovement(){//main player movement
        moving = false;
        if(Greenfoot.isKeyDown("d") && Greenfoot.isKeyDown("a") == false && (this.isAtEdge()==false || facingLeft == true)){
            moving = true;
            if(onBackStep == false && weaponID == 0){
                setImage("mainguy1.png");
                move(movespeed);
                speedx = (int)Math.round(movespeed);
                xpos = xpos + (int)movespeed;
            }
            if (onBackStep == true && weaponID == 0){
                setImage("mainguy2.png");
                move(movespeed);
                speedx = (int)Math.round(movespeed);
                xpos = xpos + (int)movespeed;
            }
            if (getOneIntersectingObject(Floor.class) != null && ground() == false && Greenfoot.isKeyDown("d") == false){
                move(movespeed);
                speedx = (int)Math.round(movespeed);
                xpos = xpos + (int)movespeed;
            }

            //steal code here
            facingLeft = false;
        }

        if(Greenfoot.isKeyDown("a") && Greenfoot.isKeyDown("d") == false && (this.isAtEdge()==false || facingLeft == false)){
            moving = true;
            if(onBackStep == false && weaponID == 0){
                setImage("mainguy3.png");
                move(movespeed);
                speedx = (int)Math.round(movespeed);
                xpos = xpos - (int)movespeed;
            }
            if (onBackStep == true && weaponID == 0){
                setImage("mainguy4.png");
                move(movespeed);
                speedx = (int)Math.round(movespeed);
                xpos = xpos - (int)movespeed;
            }
            if (getOneIntersectingObject(Floor.class) != null && ground() == false && Greenfoot.isKeyDown("d") == false){
                move(movespeed);
                speedx = (int)Math.round(movespeed);
                xpos = xpos - (int)movespeed;
            }
            //steal code here
            facingLeft = true;
        }

    }

    public void dirChangeTest(){
        if(facingLeft == true){
            if(Greenfoot.isKeyDown("d")){
                movespeed = -movespeed;
            }
        }
        if(facingLeft == false){
            if(Greenfoot.isKeyDown("a")){
                movespeed = -movespeed;
            }
        }
    }

    /*public void playerMovement2(){//main player movement
    movespeed = movespeed * 2;
    if(Greenfoot.isKeyDown("d") && Greenfoot.isKeyDown("a") == false){
    moving2 = true;movespeed = movespeed;
    if(onBackStep == false && weaponID == 0){
    setImage("mainguy1.png");
    move(movespeed * 2);
    speedx = (int)Math.round(movespeed);
    }
    if (onBackStep == true && weaponID == 0){
    setImage("mainguy2.png");
    move(movespeed);
    speedx = (int)Math.round(movespeed);
    }
    if (getOneIntersectingObject(Floor.class) != null && ground() == false && Greenfoot.isKeyDown("d") == false){
    move(movespeed);
    speedx = (int)Math.round(movespeed);
    }
    }
    else{
    moving2 = false;
    }
    if(Greenfoot.isKeyDown("a") && Greenfoot.isKeyDown("d") == false){
    moving2 = true;
    if(onBackStep == false && weaponID == 0){
    setImage("mainguy3.png");
    move(-movespeed);
    speedx = (int)Math.round(-movespeed);
    }
    if (onBackStep == true && weaponID == 0){
    setImage("mainguy4.png");
    move(-movespeed);
    speedx = (int)Math.round(-movespeed);
    }
    if (getOneIntersectingObject(Floor.class) != null && ground() == false && Greenfoot.isKeyDown("d") == false){
    move(movespeed);
    speedx = (int)Math.round(movespeed);
    }
    }
    else{
    moving2 = false;
    }
    }*/

    public void playerModel(){ //walking animation
        walkTimer++;
        if(walkTimer < 15){
            onBackStep = false;
        }
        if(walkTimer > 15 && walkTimer < 30){
            onBackStep = true;
        }
        if(walkTimer == 30){
            walkTimer = 0;
        }
    }

    public void playerPulse(){
        pulseTimer++;
        if(pulseTimer < pulsescale){
            curscale++;
        }
        if(pulseTimer >= pulsescale && pulseTimer < 2*pulsescale){
            curscale--;
        }
        if(pulseTimer == 2*pulsescale){
            curscale = normscale;
            pulseTimer = 0;
        }
    }

    public void sprint(){
        if(Greenfoot.isKeyDown("shift")){
            if(movespeed < maxspeed){
                movespeed++;
            }
        }
        if (!(Greenfoot.isKeyDown("shift"))){
            movespeed = basespeed;
        }
    }

    public void jump(){//main player jump abaility, Peter did this
        ground();
        checkFall();
        gravityjump();
        timerjump();
        actualJump();
    }

    public void timerjump(){ //determines if jump is over and if falling starts
        timer--;
        if (timer<0){
            jumping = false;
        }
        jumpreset--;
        if(jumpreset < 0){
            jumpres = false;
        }else
        {
            jumpres = true;
        }

    }

    public void actualJump(){ //checks if space is activated and not jumping currently as well as not falling
        if (Greenfoot.isKeyDown("space") && jumping == false && falling == false && jumpres == false){
            jumping = true;
            timer = 6;
            gravity = -timer;
            falling = true;
        }
    }

    public boolean ground(){ //checks if ground is below char
        //FLOOR is the colliding object
        Object under = getOneObjectAtOffset(0, getImage().getHeight()/2 + 2, Floor.class);
        return under != null;
    }

    public void checkFall(){ //checks if ground is below and jump is not active to not trigger false triggers
        //check if ground is below and not jumping
        Object infronts = getOneObjectAtOffset(0+direction, getImage().getHeight()/2 + 2, Floor.class);
        if(infronts != null){
            infront = true;
        }else{
            infront = false;
        }
        Object behinds = getOneObjectAtOffset(0-direction, getImage().getHeight()/2 + 2, Floor.class);
        if(behinds != null){
            inbehind = true;
        }else{
            inbehind = false;
        }
        if((falling == true || jumping == true) && (infront == true || inbehind == true || ground() == true))
        {
            jumpreset = 30;
        }
        if((infront == true || inbehind == true) && jumping ==false){
            speed = 0;
            falling = false;
        }
        if(ground() == true  && jumping == false){
            speed = 0;
            falling = false;
        }
    }
    int jk;
    private boolean moved = false;
    public void gravityjump(){ //gravity applying force every frame
        moved = false;
        if(gravity != 1){
            gravity++;
        }
        if(falling == true){
            for(int l = speed + 2; l > 0; l--)
            {
                Object behinds = getOneObjectAtOffset(0, getImage().getHeight()/2 + l, Floor.class);
                if(behinds == null){
                    setLocation(getX(), getY() + jk);
                    moved = true;
                } else {
                    jk = l;
                }
            }
        }
        if(moved == false)
            setLocation(getX(), getY() + speed);
        speed += gravity;

    }

    public void findDoor(){
        if(this.getOneObjectAtOffset(0, 0, Door.class) != null){
            isTouchingDoor = true;
        }
        else{
            isTouchingDoor = false;
        }
    }

    public void moveEffects() //movement that is affected by powerups and traps
    {
        if (stunDelay < 0)
        {
            jump();
            if(speedTimer < 0)
            {

                playerMovement();
            }
            else
            {
                //playerMovement2();
                speedTimer--;
            }
        }
        else
        {
            stunDelay--;
        }
    }

    public void setSpeedTimer()
    {
        speedTimer = 200;
    }

    public void stun()
    {
        stunDelay = 50;
    }

    public void addHealthOne()
    {
        if (health < 5)
        {
            health += 1;
        }
    }

    public void addHealthTwo()
    {
        if (health < 3)
        {
            health += 3;
        }
        if (health == 3)
        {
            health += 2;
        }
        if (health == 4)
        {
            health += 1;
        }
    }

    public void takeTrapDamage()
    {
        health -= 1;
    }

    //steal allow below
    public void combat(){
        //Punch by David
        triangleMaker();
        punchTime();
    }
    int punchTimer = 0;
    public static boolean facingLeft;
    boolean punchReady = true;
    public void triangleMaker(){
        triangleMakerRight();
        triangleMakerLeft();
    }

    public void triangleMakerRight(){
        if(Greenfoot.isKeyDown("j") && punchReady == true && facingLeft == false){
            punchTimer = 40;
            punchReady = false;
            PunchTriangle punchTriangle = new PunchTriangle();
            getWorld().addObject(punchTriangle,CharacterX+75,CharacterY);
        }
    }

    public void triangleMakerLeft(){
        if(Greenfoot.isKeyDown("j") && punchReady == true && facingLeft == true){
            punchTimer = 40;
            punchReady = false;
            PunchTriangle2 punchTriangle2 = new PunchTriangle2();
            getWorld().addObject(punchTriangle2,CharacterX-75,CharacterY);
        }
    }

    public void punchTime(){
        if(punchTimer < 0){
            punchReady = true;
        }
        punchTimer--;
    }
    int health = 5;
    public void damage (int dmg)
    {
        health = health-dmg;
        kockbackE=true;
        if (health == 0)
        {
            TitleScreen world = new TitleScreen();
            Greenfoot.setWorld(world);
        }
    }

    public int kTimerE;
    public boolean kockbackE = false;
    public int knockbackPowerE = 50;
    public void Knockback()
    {
        kTimerE++;
        if (kTimerE % 6 == 0)
        {
            kockbackE = false;
            kTimerE = 0;
        }
         if (kockbackE == true)
        {
            List<Enemy> list;
            list= getObjectsInRange(750, Enemy.class);
            if (list != null && ! list.isEmpty()){
            
                
            Enemy e = (Enemy) list.get(0);
            if (e.getX() > this.getX())
            {
                ((Scroll)getWorld()).shiftWorld((int)Math.round(movespeed+15),0);
            }
            if ( e.getX()< this.getX())
            {
                ((Scroll)getWorld()).shiftWorld((int)Math.round(-movespeed-15),0);
            }
        }
    }
    }

    public void boundedMove(){
        int argR = Scroll.getWWidth() - BOUNDARY;
        if (moving == true){
            /*if(xpos <= BOUNDARY){
            atEdgeL = false;
            }
            else{
            atEdgeL = true;
            }
            if(xpos >= argR){
            atEdgeR = true;
            }
            else{
            atEdgeR = false;
            }
            if(atEdgeL == true || atEdgeR == true){
            atAnEdge = true;
            }
            else{
            atAnEdge = false;cf
            }*/
            //((DormHall)getWorld()).shiftWorld(5,0);
            if(Greenfoot.isKeyDown("d")){
                if(atAnEdge == false){
                    if(movespeed+getX() >= BOUNDARY)
                    {
                        setLocation(BOUNDARY, getY());
                        ((Scroll)getWorld()).shiftWorld(((int)Math.round(-movespeed)),0);

                    }
                }
            }

            else if((-movespeed)+getX() <= getWorld().getWidth() - BOUNDARY){
                if(Greenfoot.isKeyDown("a")){
                    if(atAnEdge == false){
                        setLocation(getWorld().getWidth()-BOUNDARY, getY());
                        ((Scroll)getWorld()).shiftWorld((int)Math.round(movespeed),0);

                    }
                }

            }
        }
        //if(jumpres  == true || falling == true){
        if(speedy+getY() <= BOUNDARY){
            //setLocation(getX(), BOUNDARY);
            ((Scroll)getWorld()). shiftWorld(0,-speedy);
        } else if(speed+getY() >= getWorld().getHeight()-BOUNDARY){
            //setLocation(getX(), getWorld().getHeight()-BOUNDARY);
            ((Scroll)getWorld()).shiftWorld(0, -speedy);
        }else{
            //setLocation(getX(), getY() + speed);
        }
        //}
        speedx = 0;
        speedy = 0;
    }

    public void shooting()
    {
       
         if (Greenfoot.isKeyDown("k") && shotTimer == 0) {
            int st = WeaponGUI.getShotType();
            if(st == 0 && regAmmo > 0){
                fireBullet();
                regAmmo -= 1;
                shotTimer = 50; // delay next shot
            }
            else if(st == 1 && stunAmmo > 0){
                fireStunBullet();
                stunAmmo -= 1;
                shotTimer = 50;
            }
            else if(st == 2 && fleeAmmo > 0){
                fireFleeBullet();
                fleeAmmo -= 1;
                shotTimer = 50;
            }
            fireRes = true;
        }
    }

    /*public void stunShooting()
    {
        if (shotTimer > 0)
        {
            shotTimer = shotTimer - 10;
        }
        else if (Greenfoot.isKeyDown("n"))
        {
            fireStunBullet();
            stunAmmo -= 1;
            shotTimer = 50;
        }
    }

    public void fleeShooting()
    {
        if (shotTimer > 0)
        {
            shotTimer = shotTimer - 10;
        }
        else if (Greenfoot.isKeyDown("m"))
        {
            fireFleeBullet();
            fleeAmmo -= 1;
            shotTimer = 50;
        }
    }*/

    public void addRegAmmo()
    {
        regAmmo =+ 5;
    }

    public void addStunAmmo()
    {
        stunAmmo += 3;
    }

    public void addFleeAmmo()
    {
        fleeAmmo += 1;
    }
    public static int getRegAmmo(){
        return regAmmo;
    }
    public static int getStunAmmo(){
        return stunAmmo;
    }
    public static int getFleeAmmo(){
        return fleeAmmo;
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ra here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Armstrongcs extends CutsceneActors
{
    /**
     * Act - do whatever the Ra wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Armstrongcs(){
        image.scale(curscale, curscale);
        setImage(image);

    }
    public GreenfootImage image = getImage();
    private int pulsescale = 5;
    private int normscale = 200;
    private int curscale = normscale;
    private int pulseTimer = 0;
    public void act() 
    {

    }

    public void talking(){
        pulseTimer++;
        if(pulseTimer < pulsescale){
            curscale++;
        }
        if(pulseTimer >= pulsescale && pulseTimer < 2*pulsescale){
            curscale--;
        }
        if(pulseTimer == 2*pulsescale){
            curscale = normscale;
            pulseTimer = 0;
        }
        image.scale(curscale, curscale);
        setImage(image);
    }
    public void dirChangeL(){
        setImage("pres3.png");
        image = this.getImage();
        image.scale(200, 200);
    }
    public void dirChangeR(){
        setImage("pres1.png");
        image = this.getImage();
        image.scale(200, 200);
    }
}

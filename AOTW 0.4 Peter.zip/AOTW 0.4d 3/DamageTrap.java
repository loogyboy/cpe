import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DamageTrap here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DamageTrap extends Powerups
{
    /**
     * Act - do whatever the DamageTrap wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public DamageTrap(int x, int y)
    {
        super(x, y);
    }
    
    public DamageTrap()
    {
        super();
    }
    
    protected void checkHitCharacter()
    {
        if (!getObjectsInRange(100, Character.class).isEmpty())
        {
            Character chars = getObjectsInRange(100, Character.class).get(0);
            chars.takeTrapDamage();
            getWorld().removeObject(this);
        }
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StunAmmoPack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StunAmmoPack extends Powerups
{
    public StunAmmoPack(int x, int y)
    {
        super(x, y);
    }
    
    public StunAmmoPack()
    {
        super();
    }
    
    protected void checkHitCharacter()
    {
        if (!getObjectsInRange(100, Character.class).isEmpty())
        {
            Character chars = getObjectsInRange(100, Character.class).get(0);
            chars.addStunAmmo();
            getWorld().removeObject(this);
        }
    }  
}

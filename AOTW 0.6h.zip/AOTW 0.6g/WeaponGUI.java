import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WeaponGUI here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WeaponGUI extends GUI
{
    /**
     * Act - do whatever the WeaponGUI wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public WeaponGUI(){
        image = this.getImage();
        image.scale(200,100);
        setImage(image);
        shotType = 0;
        
    }
    private static int shotType;
    GreenfootImage image;
 
    public void act() 
    {
        setChoice();
        image = this.getImage();
        image.scale(200,100);
        
    }    
    private void setChoice(){
        if(Greenfoot.isKeyDown("1")){
            shotType = 0;
        }
        else if(Greenfoot.isKeyDown("2")){
            shotType = 1;
        }
        else if(Greenfoot.isKeyDown("3")){
            shotType = 2;
        }
        if(shotType == 0){
            setImage("weaponscroll.png");
        }
        else if(shotType == 1){
            setImage("weaponscroll1.png");
        }
        else if(shotType == 2){
            setImage("weaponscroll2.png");
        }
    }
    public static int getShotType(){
        return shotType;
    }
    /*private void setAmmoRem(){
        if(shotType == 0){
            am = Character.getRegAmmo();
        }
        else if(shotType == 1){
            am = Character.getStunAmmo();
        }
        else if(shotType == 2){
            am = Character.getFleeAmmo();
        }
        ammocounter.setValue(am);
    }*/
}

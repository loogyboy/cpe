import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DormRoom extends Scroll
{
    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 800;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public DormRoom()
    {    
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 800, 450, new GreenfootImage("dormroomlevel.png"));
        prepare();

    }
    private Character main;
    private Door exit;
    

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    public void act(){
        DoorTest();
    }
    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);
        Character character = new Character();
        main = character;
        main.worldID = 1;
        addObject(character,148,330);
        Door door = new Door();
        exit = door;
        addObject(door,617,365);
    }
    public Character getPlayer(){
        return main;
    }
    public Door getDoor(){
        return exit;
    }
    public void DoorTest(){
        int doorX = this.getDoor().getX();
        int doorY = this.getDoor().getY();
        int playerX = this.getPlayer().getX();
        int playerY = this.getPlayer().getY();
        int rangeX1 = doorX - 150;
        int rangeX2 = doorX + 150;
        int rangeY1 = doorY - 150;
        int rangeY2 = doorY + 150;
        if((playerX > rangeX1 && playerX < rangeX2) && (playerY > rangeY1 && playerY < rangeY2)){
            DoorMessage pressX = new DoorMessage();
            addObject(pressX,this.getWidth()/2, this.getWidth()/10);
            if(Greenfoot.isKeyDown("x")){
                this.removeObjects(this.getObjects(Actor.class));
                getDoor().toWorld();
            }
        }
        else{
            this.removeObjects(this.getObjects(DoorMessage.class));
        }
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DormRoom extends World
{
    private int xOffset = 0;
    private final static int SWIDTH = 1600;
    private final static int SHEIGHT = 900;
    private final static int WWIDTH = 1080;
    private GreenfootImage bimg;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public DormRoom()
    {    
        super(SWIDTH, SHEIGHT, 1, false);
        bimg = new GreenfootImage("dormroomlevel.png");
        bimg.scale(getWidth(), getHeight());
        setBackground(bimg);
        shiftWorld(0);
        prepare();
    }
    public void shiftWorld(int dx) 
    {
        if( (xOffset + dx) <= 0 && (xOffset + dx) >= SWIDTH - WWIDTH)
        {
            xOffset = xOffset + dx;
            shiftWorldBackground(dx);
            shiftWorldActors(dx);
        }
    }
    private void shiftWorldBackground(int dx) {
        GreenfootImage bkgd = new GreenfootImage(SWIDTH, SHEIGHT);
        bkgd.drawImage(bimg, xOffset, 0);
        setBackground(bkgd);
    }
    private void shiftWorldActors(int dx) 
    {
        List<Character> saList =
        getObjects(Character.class);
        for( Character a : saList ) {
            a.setAbsoluteLocation(dx);
        }
    }
     private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,752,898);;
        Character character = new Character();
        main = character;
        addObject(character,296,673);
        character.setLocation(296,673);
        Door door = new Door();
        exit = door;
        addObject(door,1235,731);
    }
  
    private Character main;
    private Door exit;

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    public void act(){
        DoorTest();
    }

   

    public Character getPlayer(){
        return main;
    }

    public Door getDoor(){
        return exit;
    }

    public void DoorTest(){
        int doorX = this.getDoor().getX();
        int doorY = this.getDoor().getY();
        int playerX = this.getPlayer().getX();
        int playerY = this.getPlayer().getY();
        int rangeX1 = doorX - 150;
        int rangeX2 = doorX + 150;
        int rangeY1 = doorY - 150;
        int rangeY2 = doorY + 150;
        if((playerX > rangeX1 && playerX < rangeX2) && (playerY > rangeY1 && playerY < rangeY2)){
            DoorMessage pressX = new DoorMessage();
            addObject(pressX,this.getWidth()/2, this.getWidth()/10);
            if(Greenfoot.isKeyDown("x")){
                this.removeObjects(this.getObjects(Actor.class));
                getDoor().toWorld();
            }
        }
        else{
            this.removeObjects(this.getObjects(DoorMessage.class));
        }
    }

    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Armstrong here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Armstrong extends EnemyBase
{
    public int enemyNumber;
    
    /**
     * Act - do whatever the Armstrong wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public void spawnOne()
    {
        if( Greenfoot.getRandomNumber(1000) < 3)
        {
            Enemy enemy = new Enemy();
            World w = (World) getWorld();
        w.addObject(enemy,getX() - 2, getY());
        }
    }
    public void massPhase()
    {
        if (enemyNumber != 3){
        Enemy enemy = new Enemy();
            World w = (World) getWorld();
        w.addObject(enemy,getX() - 2, getY()); 
        enemyNumber++;
    }
    
}
}

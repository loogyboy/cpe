import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class DormHall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DormHall extends Scroll
{

    private final static int SWIDTH1 = 1600;
    private final static int SHEIGHT1 = 900;
    private final static int WWIDTH1 = 12800;
    private final static int WHeight1 = 900;
    //GreenfootImage img = new GreenfootImage("dormhalllevel.png");
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
  
    public DormHall()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 12800, 900, new GreenfootImage("dormhalllevel.png"));
        prepare();
    }
    
    
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,861,894);
        Floor floor2 = new Floor();
        addObject(floor2,2623,894);
        Floor floor3 = new Floor();
        addObject(floor3,4374,894);
        Floor floor4 = new Floor();
        addObject(floor4,6065,894);
        Floor floor5 = new Floor();
        addObject(floor5,7779,894);
        Floor floor6 = new Floor();
        addObject(floor6,9438,894);
        Floor floor7 = new Floor();
        addObject(floor7,10977,894);
        Floor floor8 = new Floor();
        addObject(floor8,12461,894);
        TableTop tabletop = new TableTop();
        addObject(tabletop,6400,672);
        Couch couch = new Couch();
        addObject(couch,5030,789);
        couch.setLocation(5030,768);
        couch.setLocation(5032,770);
        Chair chair = new Chair();
        addObject(chair,7733,790);
        chair.setLocation(7725,769);
        Character character = new Character();
        addObject(character,198,670);
    //    main = character;
        //main.worldID = 2;
        Enemy enemy = new Enemy();
        addObject(enemy,1186,670);
        Enemy enemy2 = new Enemy();
        addObject(enemy2,3378,670);
        Enemy enemy3 = new Enemy();
        addObject(enemy3,5364,670);
        Enemy enemy4 = new Enemy();
        addObject(enemy4,7908,670);
        Gum gum = new Gum();
        addObject(gum,3698,695);
        Gum gum2 = new Gum();
        addObject(gum2,5096,718);
        Gum gum3 = new Gum();
        addObject(gum3,6540,679);
        Gum gum4 = new Gum();
        addObject(gum4,8209,677);
        SpeedUp speedup = new SpeedUp();
        addObject(speedup,11858,730);
        Enemy enemy5 = new Enemy();
        addObject(enemy5,1771,658);
        Enemy enemy6 = new Enemy();
        addObject(enemy6,4423,685);
        Enemy enemy7 = new Enemy();
        addObject(enemy7,6791,665);
        Enemy enemy8 = new Enemy();
        addObject(enemy8,9165,660);
        Enemy enemy9 = new Enemy();
        addObject(enemy9,10957,682);
        gum2.setLocation(5544,614);
        enemy3.setLocation(5612,648);
        enemy4.setLocation(8276,554);
        gum2.setLocation(4979,548);
        gum2.setLocation(5815,700);
        enemy3.setLocation(5600,669);
        gum3.setLocation(6560,750);
        
    }
}

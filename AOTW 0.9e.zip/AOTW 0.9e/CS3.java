import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS3 extends World
{

    /**
     * Constructor for objects of class CS1.
     * 
     */
    GreenfootImage bg;
    Player player;
    Amy amy;
    private int cstimer = 0;
    public CS3()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("dormhallcs.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);

        player = new Player();
        addObject(player,600,330);

        amy = new Amy();
        addObject(amy,0,330);
    }

    public void act(){
        cstimer++;
        if(cstimer == 1){
            player.dirChange();
        }
        if(cstimer > 5 && cstimer < 175) {
            amy.amyTalking();
        }
        if(cstimer == 5) {
            //Greenfoot.playSound("AmyVoice1.wav");
        }
        if(cstimer > 175 && cstimer < 405) {
           player.playerTalking();
        }
        if(cstimer == 175) {
            //Greenfoot.playSound("PlayerVoice1.wav");
        }
        if(cstimer > 405 && cstimer < 1000) {
            amy.amyTalking();
        }
        if(cstimer == 405) {
            //Greenfoot.playSound("AmyVoice2.wav");
        }
        if(cstimer > 1000 && cstimer < 1200) {
           player.playerTalking();
        }
        if(cstimer == 1000) {
            //Greenfoot.playSound("PlayerVoice2.wav");
        }
        if(cstimer > 1200 && cstimer < 1900) {
            amy.amyTalking();
        }
        if(cstimer == 1200) {
            //Greenfoot.playSound("AmyVoice3.wav");
        }
        if(cstimer > 1900 && cstimer < 2100) {
           player.playerTalking();
        }
        if(cstimer == 1900) {
            //Greenfoot.playSound("PlayerVoice3.wav");
        }
        if(cstimer > 2100 && cstimer < 2500) {
            amy.amyTalking();
        }
        if(cstimer == 2100) {
            //Greenfoot.playSound("AmyVoice4.wav");
        }
        if(cstimer == 5000){
            Baker baker = new Baker();
            Greenfoot.setWorld(baker);
        }
    }
    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class EnemyBase here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyBase extends Scrolling
{
    /**
     * Act - do whatever the EnemyBase wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() {
    
        }
    private boolean following = false;
     public boolean active = false;
     
            
            
            
           
        
   
     private int canChange;
    public boolean facingLeft = false;
   
    public boolean kockback = false;
  
    private int eSpeed = 2;
    private boolean onBackStep = false;
    
    
    private int walkTimer = 0; //Times onStepBack in order to switch images at even intervals
    private int weaponID = 0; //controls weapon type, 0 is bare hands
    private double movespeed = 5;
    private int speed;
    private int gravity = 1;
    private boolean jumping;
    private int timer;
    private boolean falling;
    private boolean infront;
    private boolean inbehind;
    private int direction = 80;
    private int jumpreset;
    private boolean jumpres;
   
    private int stunDelay = -1;
    private int fleeTimer = -1;
    public void checkFall(){ //checks if ground is below and jump is not active to not trigger false triggers
        //check if ground is below and not jumping
        Object infronts = getOneObjectAtOffset(0+direction, getImage().getHeight()/2 + 2, Floor.class);
        if(infronts != null){
            infront = true;
        }else{
            infront = false;
        }
        Object behinds = getOneObjectAtOffset(0-direction, getImage().getHeight()/2 + 2, Floor.class);
        if(behinds != null){
            inbehind = true;
        }else{
            inbehind = false;
        }
        if((falling == true || jumping == true) && (infront == true || inbehind == true || ground() == true))
        {
            jumpreset = 30;
        }
        if((infront == true || inbehind == true) && jumping ==false){
            speed = 0;
            falling = false;
        }
        if(ground() == true  && jumping == false){
            speed = 0;
            falling = false;
        }
    }
    public void gravityjump(){ //gravity applying force every frame
        if(gravity != 1){
            gravity++;
        }
        setLocation(getX(), getY() + speed);
        speed += gravity;
    }
     public boolean ground(){ //checks if ground is below char
        //FLOOR is the colliding object
        Object under = getOneObjectAtOffset(0, getImage().getHeight()/2 + 2, Floor.class);
        return under != null;
    }
    
     
}

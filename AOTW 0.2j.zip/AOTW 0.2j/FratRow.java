import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class FratRow here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratRow extends World
{

    /**
     * Constructor for objects of class FratRow.
     * 
     */
     private int xOffset = 0;
    private int yOffset = 0;
    private final static int SWIDTH = 1600;
    private final static int SHEIGHT = 900;
    private final static int WWIDTH = 3330;
    private final static int WHeight = 900;
    private GreenfootImage cimg;
    public FratRow()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        //super(SWIDTH, SHEIGHT, 1, false);
        super(4330, 1900, 1/*, false*/);
        cimg= new GreenfootImage("FratRow.png");
        cimg.scale(getWidth(), getHeight());
        setBackground(cimg);
        //shiftWorld(0,0);
        prepare();
    }
    private Character main;
    private Door exit;
    private Door entry;
    private GreenfootImage bkgd;
    public void shiftWorld(int dx, int dy) 
    {
        if( (xOffset + dx) <= 0 && (xOffset + dx) >= SWIDTH - WWIDTH)
        {
            xOffset = xOffset + dx;
            shiftWorldBackground(dx,0);
            shiftWorldActors(dx,0);
        }
        if ( (yOffset + dy) <= 0 && (yOffset + dy) >= SHEIGHT - WHeight)
        {
            yOffset = yOffset + dy;
            shiftWorldBackground(0,dy);
            shiftWorldActors(0,dy);
        }
    }

    private void shiftWorldBackground(int dx, int dy) {
        bkgd = new GreenfootImage(SWIDTH, SHEIGHT);
        bkgd.drawImage(cimg, xOffset, yOffset);
        setBackground(bkgd);
    }

    private void shiftWorldActors(int dx, int dy) 
    {
        List<Scrolling> saList =
            getObjects(Scrolling.class);
        for( Scrolling a : saList ) {
            a.setAbsoluteLocation(dx,dy);
        }
    }
    
    private void prepare()
    {

        Floor floor = new Floor();
        addObject(floor,898,1879);
        Floor floor2 = new Floor();
        addObject(floor2,2698,1879);
        Floor floor3 = new Floor();
        addObject(floor3,4299,1879);
        Window window = new Window();
        addObject(window,660,1633);

        Window window2 = new Window();
        addObject(window2,133,1654);

        Window window3 = new Window();
        addObject(window3,583,1205);

        Window window4 = new Window();
        addObject(window4,185,1215);

        Window window5 = new Window();
        addObject(window5,1385,1268);
        Window window6 = new Window();
        addObject(window6,1694,1250);
        Window window7 = new Window();
        addObject(window7,1934,1281);
        Window window8 = new Window();
        addObject(window8,1426,1643);
        Window window9 = new Window();
        addObject(window9,1940,1646);
        window5.setLocation(1386,1249);
        window6.setLocation(1661,1227);
        window7.setLocation(1954,1239);
        window8.setLocation(1372,1723);
        window9.setLocation(1964,1734);
        Window window10 = new Window();
        addObject(window10,2596,1238);
        window10.setLocation(2587,1204);
        Window window11 = new Window();
        addObject(window11,3128,1214);
        window11.setLocation(3101,1193);
        Window window12 = new Window();
        addObject(window12,2602,1647);
        window12.setLocation(2586,1657);
        Window window13 = new Window();
        addObject(window13,3128,1697);
        window13.setLocation(3100,1656);
        Window window14 = new Window();
        addObject(window14,3633,1167);
        window14.setLocation(3626,1124);
        Window window15 = new Window();
        addObject(window15,3881,1143);
        Window window16 = new Window();
        addObject(window16,4081,1159);
        Window window17 = new Window();
        addObject(window17,3848,1612);
        Window window18 = new Window();
        addObject(window18,3658,1612);
        window15.setLocation(3858,1125);
        window16.setLocation(4091,1126);
        window17.setLocation(3854,1612);
        window17.setLocation(3852,1611);
        window18.setLocation(3636,1612);
        window18.setLocation(3633,1609);
        Table table = new Table();
        addObject(table,758,1725);
        table.setLocation(761,1765);
        Table table2 = new Table();
        addObject(table2,3360,1790);
        table2.setLocation(3376,1782);
        table.setLocation(974,1769);
        table.setLocation(985,1800);
        table.setLocation(956,1774);
    }
}



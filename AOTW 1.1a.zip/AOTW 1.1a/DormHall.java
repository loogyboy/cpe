import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class DormHall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DormHall extends Scroll
{

    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 6400;
    private final static int WHeight1 = 450;
    //GreenfootImage img = new GreenfootImage("dormhalllevel.png");
    /*Counter ac;
    Character character;
    private int am;*/
    public GreenfootSound bkgMusic;
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */

    public DormHall()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 6400, 450, new GreenfootImage("dormhalllevel.png"));
        prepare();
        worldID = 1;
        bkgMusic = new GreenfootSound("Mountain Emperor.mp3");
        bkgMusic.playLoop();
    }

    public void act(){
        cutscene2();
        setAmmoRem();
        testDead();
    }

    private void prepare()
    {
        //Floors
        Floor floor = new Floor();
        addObject(floor,861,447);
        Floor floor2 = new Floor();
        addObject(floor2,2623,447);
        Floor floor3 = new Floor();
        addObject(floor3,4374,447);
        Floor floor4 = new Floor();
        addObject(floor4,6065,447);
        Floor floor5 = new Floor();

        //Objects in Environment
        TableTop tabletop = new TableTop();
        addObject(tabletop,3200,336);
        Couch couch = new Couch();
        addObject(couch,2516,380);
        Chair chair = new Chair();
        addObject(chair,3862,380);

        //Powerups
        Gum gum = new Gum();
        addObject(gum, 1000, 400);
        HealthPackOne hpo = new HealthPackOne();
        addObject(hpo, 2500, 300);
        StunAmmoPack sap = new StunAmmoPack();
        addObject(sap, 2600, 300);
        StunAmmoPack sap2 = new StunAmmoPack();
        addObject(sap2, 2400, 300);
        FleeAmmoPack fap = new FleeAmmoPack();
        addObject(fap, 3200, 300);
        FleeAmmoPack fap2 = new FleeAmmoPack();
        addObject(fap2, 3300, 300);
        FleeAmmoPack fap3 = new FleeAmmoPack();
        addObject(fap3, 3100, 300);
        RegAmmoPack rap = new RegAmmoPack();
        addObject(rap, 1930, 325);
        RegAmmoPack rap2 = new RegAmmoPack();
        addObject(rap2, 1850, 325);
        RegAmmoPack rap3 = new RegAmmoPack();
        addObject(rap3, 1890, 225);
        HealthPackTwo hpt = new HealthPackTwo();
        addObject(hpt, 4080, 310);

        //Character
        character = new Character();
        addObject(character,100,335);
        //main = character;
        //main.worldID = 2;

        //Enemies
        //Enemy enemy = new Enemy();
        //addObject(enemy,600,335);
        //Enemy enemy2 = new Enemy();
        //addObject(enemy2,1500,335);
        Enemy enemy3 = new Enemy();
        addObject(enemy3,2500,335);
        Enemy enemy4 = new Enemy();
        addObject(enemy4,4000,335);
        Enemy enemy5 = new Enemy();
        addObject(enemy5,1800,335);
        Enemy enemy6 = new Enemy();
        addObject(enemy6,2200,335);
        Enemy enemy7 = new Enemy();
        addObject(enemy7,3300,335);
        Enemy enemy8 = new Enemy();
        addObject(enemy8,4500,335);
        Enemy enemy9 = new Enemy();
        addObject(enemy9,5000,335);

        GUI();
        health();
        /*Counter ammocounter = new Counter();
        addObject(ammocounter, 700, 110);
        ac = ammocounter;
        am = character.getRegAmmo();
        ac.setValue(am);*/
        FleeAmmoPack fleeammopack = new FleeAmmoPack();
        addObject(fleeammopack,300,396);
        Gum tempGum = new Gum();
        addObject(tempGum,400,396);
        HealthPackTwo tempHP = new HealthPackTwo();
        addObject(tempHP,500,396);
        DamageTrap tempDT = new DamageTrap();
        addObject(tempDT,600,396);
        
        character.spawnpoint = 1;
    }

    /*private void setAmmoRem(){
    if(WeaponGUI.getShotType() == 0){
    am = character.getRegAmmo();
    }
    else if(WeaponGUI.getShotType() == 1){
    am = character.getStunAmmo();
    }
    else if(WeaponGUI.getShotType() == 2){
    am = character.getFleeAmmo();
    }
    ac.setValue(am);
    }*/
    public int getID(){
        return worldID;
    }

    private void cutscene2(){
        if(character.loc > 6200){
            CS2 cs2 = new CS2();
            Greenfoot.setWorld(cs2);
            bkgMusic.stop();
        }
    }
    private void testDead(){
        if(character.health <= 0){
            bkgMusic.stop();
        }
    }
}

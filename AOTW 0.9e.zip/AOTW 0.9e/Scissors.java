import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

            import java.util.*;
/**
 * Write a description of class Scissors here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scissors extends Scrolling
{
    /**
     * Act - do whatever the Scissors wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Scissors(){
        GreenfootImage image = getImage();  
        image.scale(75, 75);
    }
    public void act() 
    {
        List<Character> list;
        list= getObjectsInRange(100, Character.class);
        if (list.isEmpty() == false )
        {
            TitleScreen world = new TitleScreen();
            Greenfoot.setWorld(world);
        }
        
    }    
}

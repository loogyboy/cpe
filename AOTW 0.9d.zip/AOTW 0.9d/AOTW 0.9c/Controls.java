import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Controls here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Controls extends World
{
    public Controls()
        {    
            super(800, 450, 1);
            GreenfootImage bg = new GreenfootImage("Controls.png");
            bg.scale(getWidth(), getHeight());
            setBackground(bg);
            prepare();
        }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        PlayButton playbutton = new PlayButton();
        addObject(playbutton,400,270);
    }
}

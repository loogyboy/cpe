import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ControlsButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Credit extends Actor
{
     /**
     * Act - do whatever the ControlsButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Credit(){
        GreenfootImage image = getImage();  
        image.scale(200, 70);
        setImage(image);
    }

    public void act() 
    {
        clickCheck();
    }

    public void seeControls(){
        Endgame controls = new Endgame();
        Greenfoot.setWorld(controls);
    }
    public void clickCheck(){
        if(Greenfoot.mouseClicked(this)){
            seeControls();
        }
    }  
}

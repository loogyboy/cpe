import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Baker here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Baker extends Scroll
{

    private final static int SWIDTH1 =800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 3400;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class Baker.
     * 
     */
    private int scale = 5;
    //Character character;
    private GreenfootSound bkgMusic;
    public Baker()
    {    
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 3200, 450, new GreenfootImage("Baker Science.png"));// Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        prepare();
        bkgMusic = new GreenfootSound("Mountain Emperor.mp3");
        bkgMusic.playLoop();
    }
    public void act(){
        //cutscene3();
        setAmmoRem();
        cutscene4();
    }

    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,375,445);
        Floor floor2 = new Floor();
        addObject(floor2,909,445);
        character = new Character();
        addObject(character,69,298);
        Floor floor3 = new Floor();
        addObject(floor3,1600,445);
        
        RegAmmoPack rap = new RegAmmoPack();
        addObject(rap, 300, 300);
        StunAmmoPack sap = new StunAmmoPack();
        addObject(sap, 350, 250);
        FleeAmmoPack fap = new FleeAmmoPack();
        addObject(fap, 400, 300);
        Gum gum = new Gum();
        addObject(gum, 1000, 400);
        HealthPackTwo hpt = new HealthPackTwo();
        addObject(hpt, 675, 150);
        HealthPackOne hpo = new HealthPackOne();
        addObject(hpo, 1500, 150);
        HealthPackOne hpo2 = new HealthPackOne();
        addObject(hpo2, 1600, 150);
        HealthPackOne hpo3 = new HealthPackOne();
        addObject(hpo3, 1700, 150);
        StunAmmoPack sap2 = new StunAmmoPack();
        addObject(sap2, 2800, 300);
        StunAmmoPack sap3 = new StunAmmoPack();
        addObject(sap3, 2800, 250);
        RegAmmoPack rap2 = new RegAmmoPack();
        addObject(rap2, 2700, 300);
        RegAmmoPack rap3 = new RegAmmoPack();
        addObject(rap3, 2700, 250);
        FleeAmmoPack fap2 = new FleeAmmoPack();
        addObject(fap2, 2900, 300);
        FleeAmmoPack fap3 = new FleeAmmoPack();
        addObject(fap3, 2900, 250);
        
        GUI();
        health();
        character.setLocation(73,321);
        Floor floor4 = new Floor();
        addObject(floor4,2600,445);
         Enemy enemy = new Enemy();
        addObject(enemy,603,327);
        Enemy enemy1 = new Enemy();
        addObject(enemy1, 850, 327);
        Enemy enemy2 = new Enemy();
        addObject(enemy2, 1000, 327);
        Enemy enemy3 = new Enemy();
        addObject(enemy3, 1200, 327);
        Enemy enemy4 = new Enemy();
        addObject(enemy4, 1400, 327);
        Enemy enemy5 = new Enemy();
        addObject(enemy5,1600,327);
        Enemy enemy6 = new Enemy();
        addObject(enemy6, 1800, 327);
        Enemy enemy7 = new Enemy();
        addObject(enemy7, 2000, 327);
        Enemy enemy8 = new Enemy();
        addObject(enemy8, 2200, 327);
        Enemy enemy9 = new Enemy();
        addObject(enemy9, 2400, 327);
        Enemy enemy10 = new Enemy();
        addObject(enemy10, 2600, 327);
        character.spawnpoint = 3;
       
    }
    private void cutscene4(){
        if(character.loc > 3200){
            CS4 cs4 = new CS4();
            Greenfoot.setWorld(cs4);
            bkgMusic.stop();
        }
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS4 extends World
{
    GreenfootImage bg;
    Player player;
    Racs racs;
    private int cstimer = 0;
    public CS4()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("CS4.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,408,447);
        floor.setLocation(408,447);
        Character character2 = new Character();
        addObject(character2,696,318);
        character2.setLocation(645,335);
        FratBoss fratboss = new FratBoss();
        addObject(fratboss,126,348);
        fratboss.setLocation(124,313);
    }

      public void act(){
        cstimer++;
        
        if(cstimer == 50){
            BakerBoss bakerboss = new BakerBoss();
            Greenfoot.setWorld(bakerboss);
        }
    }
}

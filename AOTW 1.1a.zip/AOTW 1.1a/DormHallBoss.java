import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class DormHallBoss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DormHallBoss extends Scroll
{

    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 800;
    private final static int WHeight1 = 450;
    public boolean bossDead;
    RA ra;
    private GreenfootSound bkgMusic;
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */

    public DormHallBoss()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 800, 450, new GreenfootImage("dormhallcs.png"));
        prepare();
        worldID = 1;
        bkgMusic = new GreenfootSound("Darkling.mp3");
        bkgMusic.playLoop();
    }

    public void act(){
        //checkBoss();
        cutscene3();
        setAmmoRem();
        testDead();
    }

    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);

        character = new Character();
        addObject(character,600,330);

        ra = new RA();
        addObject(ra,50,330);

        GUI();
        health();
        character.spawnpoint = 2;
    }

    public int getID(){
        return worldID;
    }

    /*private void cutscene3(){
        if(bossDead==true){
            //if(character.getX() > 600){
            CS3 cs3 = new CS3();
            Greenfoot.setWorld(cs3);
            //}
        }
    }*/

    private void cutscene3(){
        if(ra.isDead == true){
            CS3 cs3 = new CS3();
            Greenfoot.setWorld(cs3);
            bkgMusic.stop();
        }
    }   
    private void testDead(){
        if(character.health <= 0){
            bkgMusic.stop();
        }
    }
}

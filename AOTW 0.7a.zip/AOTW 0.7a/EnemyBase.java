import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class EnemyBase here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyBase extends Scrolling
{
    /**
     * Act - do whatever the EnemyBase wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() {
        
    }
    private boolean following = false;
    public boolean active = false;

           
    public int eSpeed;
    private int canChange;
    public boolean facingLeft = false;

    
    private boolean onBackStep = false;
    private int walkTimer = 0; //Times onStepBack in order to switch images at even intervals
    private int weaponID = 0; //controls weapon type, 0 is bare hands
    private double movespeed = 5;
    private int speed;
    private int gravity = 1;
    private boolean jumping;
    private int timer;
    private boolean falling;
    private boolean infront;
    private boolean inbehind;
    private int direction = 80;
    private int jumpreset;
    private boolean jumpres;
    
    public boolean isDead = false;
    
    private int stunDelay = -1;
    private int fleeTimer = -1;
    public void checkFall(){ //checks if ground is below and jump is not active to not trigger false triggers
        //check if ground is below and not jumping
        Object infronts = getOneObjectAtOffset(0+direction, getImage().getHeight()/2 + 2, Floor.class);
        if(infronts != null){
            infront = true;
        }else{
            infront = false;
        }
        Object behinds = getOneObjectAtOffset(0-direction, getImage().getHeight()/2 + 2, Floor.class);
        if(behinds != null){
            inbehind = true;
        }else{
            inbehind = false;
        }
        if((falling == true || jumping == true) && (infront == true || inbehind == true || ground() == true))
        {
            jumpreset = 30;
        }
        if((infront == true || inbehind == true) && jumping ==false){
            speed = 0;
            falling = false;
        }
        if(ground() == true  && jumping == false){
            speed = 0;
            falling = false;
        }
    }

    public void gravityjump(){ //gravity applying force every frame
        if(gravity != 1){
            gravity++;
        }
        setLocation(getX(), getY() + speed);
        speed += gravity;
    }

    public boolean ground(){ //checks if ground is below char
        //FLOOR is the colliding object
        Object under = getOneObjectAtOffset(0, getImage().getHeight()/2 + 2, Floor.class);
        return under != null;
    }
    int health;
    public int kTimer;
    public boolean kockback = false;
    boolean dying = false;

    public void hitMelee(int dmg)
    {
        
        health = health - dmg;
        Greenfoot.playSound("punch.wav");
        kockback = true;
        
        if(health == 0){
            dying = true;
            jumping = true;
            timer = 6;
            gravity = -timer;
            falling = true;
        }
    }
    int time_death = 300;
    public void death()
    {
        World worlds = getWorld();
        if(dying == true)
        {
            time_death--;
            if(time_death <= 0){
            isDead = true;
            worlds.removeObject(this);
            Greenfoot.playSound("wilhelm.wav");

        }
        }
    }

    public void Knockback()
    {
        kTimer++;
        if (kTimer % 20 == 0)
        {
            kockback = false;
            kTimer = 0;
        }
        if (kockback == true)
        {
            if (Character.CharacterX > this.getX())
            {
                move(-7);
            }
            if (Character.CharacterX < this.getX())
            {
                move (7);
            }
        }
    }

    private int hitTimer;
    public void enemyHit(){//Made by Luke
        List<Character> list;
        list= getObjectsInRange(150, Character.class);
        if (list.isEmpty() == false )
        {
            hitTimer++;
            if(hitTimer ==40)
            {
                Character hit = (Character) list.get(0);
                hit.damage(1);
                hitTimer =0;
            }
        }

    }
    public void stun()
    {
        stunDelay = 50;
    }

    public void flee()
    {
        fleeTimer = 75;
    }
}

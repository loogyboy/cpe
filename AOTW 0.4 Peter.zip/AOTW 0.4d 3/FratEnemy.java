import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FratEnemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratEnemy extends EnemyBase
{
    private int eSpeed = 2;
       private boolean onBackStep = false;
        private int canChange;
    public boolean facingLeft = false;
    /**
     * Act - do whatever the FratEnemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        aimlessMove();
        throwBottle();
        checkFall();
            gravityjump();
    }    
    public void throwBottle()
    {
        if(Greenfoot.getRandomNumber(1000) <5)
        {
           Bottle b = new Bottle();
        if(facingLeft ==true)
        {
            b.setRotation(225);
            b.left();
        }
        else
        {
            b.setRotation(325);
            b.right();
        }

        getWorld().addObject(b, getX(), getY());
        }
    }
    public void EnemyMovement()
    //moves the enemy in the diection it's facing (Luke Underwood)
    {
        if (facingLeft == true)
        {
            move(-eSpeed);
            if(onBackStep == false){
                setImage("wowieguy3.png");
            }
            if(onBackStep == true){
                setImage("wowieguy4.png");
            }
            GreenfootImage image = getImage();  
            image.scale(200, 200);
        }
        else
        {
            move(eSpeed);
            if(onBackStep == false){
                setImage("wowieguy1.png");
            }
            if(onBackStep == true){
                setImage("wowieguy2.png");
            }
            GreenfootImage image = getImage();  
            image.scale(200, 200);
        }
    }
       public void aimlessMove()
    {
        if (kockback == false){
           
            EnemyOrient();
            EnemyMovement();
            }
        }
         private void EnemyOrient()
    //turns enemy right 50% of the time and left 50% of the time (Luke Underwood)
    {
        canChange = canChange + 1;
        if (canChange % 60 == 0)
        {
            if (Greenfoot.getRandomNumber (9) < 4)
            { 
                TurnLeft();
            }
            else {
                TurnRight();
            }

        }
    }
    public void TurnLeft()
    {
        facingLeft = true;

    }

    public void TurnRight()
    {
        facingLeft = false;
    }
    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS5 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS5 extends World
{
    GreenfootImage bg;
    Player player;
    Racs racs;
    Amy amy;
    private int cstimer = 0;
    public CS5()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("CS4.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,408,447);
        floor.setLocation(408,447);

        player = new Player();
        addObject(player,119,330);
        
        amy = new Amy();
        addObject(amy,800,330);
        
    }

      public void act(){
        cstimer++;
        if(cstimer == 1)
        {
            amy.dirChange();
        }
        if(cstimer > 1 && cstimer < 50)
        {
            amy.move(-4);
        }
        if(cstimer == 50)
        {
            Greenfoot.playSound("Amy.wav");
        }
        if(cstimer > 50 && cstimer < 300)
        {
            amy.amyTalking();
            
        }
        if(cstimer == 325)
        {
            Greenfoot.playSound("PlayerCS5.wav");
        }
        if(cstimer > 325 && cstimer < 425)
        {
            player.playerTalking();
            
        }
        if(cstimer == 475){
            FratRow fratrow = new FratRow();
            Greenfoot.setWorld(fratrow);
        }
    }
}

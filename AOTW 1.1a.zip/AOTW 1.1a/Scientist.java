import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class RA here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scientist extends EnemyBase
{
    /**
     * Act - do whatever the RA wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Scientist()
    {
        health=10;
        eSpeed=2;
        GreenfootImage image = getImage();  
        image.scale(200, 200);
        setImage(image);
    }

    public void act() 
    {

        checkFall();
        gravityjump();
        phase1();
        phase2();
        phase3();
        Knockback();
        death();
    }  
    private boolean onBackStep = false;
    private int canChange;
    public boolean facingLeft = false;

    private int walkTimer = 0; //Times onStepBack in order to switch images at even intervals
    private int weaponID = 0; //controls weapon type, 0 is bare hands
    private double movespeed = 2;
    private int speed;
    private int gravity = 1;
    private boolean jumping;
    private int timer;
    private boolean falling;
    private boolean infront;
    private boolean inbehind;
    private int direction = 80;
    private int jumpreset;
    private boolean jumpres;
    private boolean following = false;
    private int stunDelay = -1;
    private int fleeTimer = -1;
    public int fRate = 10;
    public void throwBottle()
    {
        if(Greenfoot.getRandomNumber(1000) <fRate)
        {
            Tube w = new Tube();
            if(facingLeft ==true)
            {
                w.setRotation(225);
                w.left();

            }
            else
            {
                w.setRotation(325);
                w.right();
            }

            if (health <= 15 && health >= 10)
            {
                w.scalingDamage1();
                fRate = 14;
            }
            else if (health < 10)
            {
                w.scalingDamage2();
                fRate = 18;
            }
            getWorld().addObject(w, getX(), getY());
        }

    }

    public void aimlessMove()
    {
        if (kockback == false){

            EnemyOrient();
            EnemyMovement();
        }
    }

    private void EnemyOrient()
    //turns enemy right 50% of the time and left 50% of the time (Luke Underwood)
    {
        canChange = canChange + 1;
        if (canChange % 60 == 0)
        {
            if (Greenfoot.getRandomNumber (9) < 4)
            { 
                TurnLeft();
            }
            else {
                TurnRight();
            }

        }
    }

    public void TurnLeft()
    {
        facingLeft = true;

    }

    public void TurnRight()
    {
        facingLeft = false;
    }

    public void EnemyMovement()
    //moves the enemy in the diection it's facing (Luke Underwood)
    {
        World w = (World) getWorld();
        if (kockback == false){
            if (facingLeft == true && getX() > 0) 
            {
                move(-eSpeed);
                if(onBackStep == false){
                    setImage("leadsci3.png");
                }
                if(onBackStep == true){
                    setImage("leadsci4.png");
                }
                GreenfootImage image = getImage();  
                image.scale(200, 200);
            }
            else if (facingLeft == false && getX() < w.getWidth())
            {
                move(eSpeed);
                if(onBackStep == false){
                    setImage("leadsci1.png");
                }
                if(onBackStep == true){
                    setImage("leadsci2.png");
                }
                GreenfootImage image = getImage();  
                image.scale(200, 200);
            }
        }
    }

    public void inAggroRange()
    {
        List<Character> list;
        list= getObjectsInRange(750, Character.class);
        if (list.isEmpty() == true)
        {
            following = false;
        }
        else
        {
            active = true;
            following = true;
        }
    }

    public void followCharacter()
    {
        if (kockback == false){
            if(following == true){
                if (Character.CharacterX < this.getX())
                {
                    if(onBackStep == false){
                        setImage("leadsci3.png");
                    }
                    if(onBackStep == true){
                        setImage("leadsci4.png");
                    }
                    GreenfootImage image = getImage();  
                    image.scale(200, 200);
                    facingLeft=true;
                    move(-eSpeed);
                }
                if (Character.CharacterX > this.getX())
                {
                    if(onBackStep == false){
                        setImage("leadsci1.png");
                    }
                    if(onBackStep == true){
                        setImage("leadsci2.png");
                    }
                    GreenfootImage image = getImage();  
                    image.scale(200, 200);
                    facingLeft=false;
                    move(eSpeed);
                }
                //turnTowards(Character.CharacterX, getY());
                //move(2);
            }

        }
    }

    public void phase1()
    {
        if(health >= 15)
        {
            inAggroRange();
            followCharacter();
            enemyHit();
        }
    }

    public void phase2()
    {
        if(health <= 15 && health > 5)
        {
            throwBottle();
            enemyHit();
            aimlessMove();
        }
    }

    public void phase3()
    {
        if (health <= 5)
        {

            throwBottle();
            enemyHit();

            aimlessMove();
        }
    }
}
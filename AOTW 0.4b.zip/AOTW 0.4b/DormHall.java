import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class DormHall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DormHall extends Scroll
{

    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 6400;
    private final static int WHeight1 = 450;
    //GreenfootImage img = new GreenfootImage("dormhalllevel.png");
    Counter ac;
    
    private int am;
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
  
    public DormHall()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 6400, 450, new GreenfootImage("dormhalllevel.png"));
        prepare();
        am = Character.getRegAmmo();
        ac.setValue(am);
    }
    public void act(){
        setAmmoRem();
    }
    private void prepare()
    {
        //Floors
        Floor floor = new Floor();
        addObject(floor,861,447);
        Floor floor2 = new Floor();
        addObject(floor2,2623,447);
        Floor floor3 = new Floor();
        addObject(floor3,4374,447);
        Floor floor4 = new Floor();
        addObject(floor4,6065,447);
        Floor floor5 = new Floor();

        
        //Objects in Environment
        TableTop tabletop = new TableTop();
        addObject(tabletop,3200,336);
        Couch couch = new Couch();
        addObject(couch,2516,380);
        Chair chair = new Chair();
        addObject(chair,3862,380);

        //Character
        Character character = new Character();
        addObject(character,100,335);
        //main = character;
        //main.worldID = 2;

        //Enemies
        Enemy enemy = new Enemy();
        addObject(enemy,600,335);
        Enemy enemy2 = new Enemy();
        addObject(enemy2,1500,335);
        Enemy enemy3 = new Enemy();
        addObject(enemy3,2500,335);
        Enemy enemy4 = new Enemy();
        addObject(enemy4,4000,335);
        Enemy enemy5 = new Enemy();
        addObject(enemy5,800,335);
        Enemy enemy6 = new Enemy();
        addObject(enemy6,2200,335);
        Enemy enemy7 = new Enemy();
        addObject(enemy7,3300,335);
        Enemy enemy8 = new Enemy();
        addObject(enemy8,4500,335);
        Enemy enemy9 = new Enemy();
        addObject(enemy9,5000,335);
        
        WeaponGUI weapongui = new WeaponGUI();
        addObject(weapongui,700,50);
        Counter ammocounter = new Counter();
        addObject(ammocounter, 700, 110);
        ac = ammocounter;
    }
    private void setAmmoRem(){
        if(WeaponGUI.getShotType() == 0){
            am = Character.getRegAmmo();
        }
        else if(WeaponGUI.getShotType() == 1){
            am = Character.getStunAmmo();
        }
        else if(WeaponGUI.getShotType() == 2){
            am = Character.getFleeAmmo();
        }
        ac.setValue(am);
    }
}

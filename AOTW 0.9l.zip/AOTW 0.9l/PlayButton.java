import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PlayButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PlayButton extends Actor
{
    /**
     * Act - do whatever the PlayButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public PlayButton(){
        GreenfootImage image = getImage();  
        image.scale(200, 70);
        setImage(image);
    }

    public void act() 
    {
        clickCheck();
    }

    public void beginGame(){
        Controls room = new Controls();
        Greenfoot.setWorld(room);
    }
    public void clickCheck(){
        if(Greenfoot.mouseClicked(this)){
            beginGame();
        }
    }
}

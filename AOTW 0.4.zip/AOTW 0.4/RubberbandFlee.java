import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RubberbandFlee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RubberbandFlee extends Scrolling
{
    public int speed;
    public int timerD = 200;
    /**
     * Act - do whatever the RubberbandBullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       
        // Add your action code here.
        
        Actor RubberbandBullet = getOneIntersectingObject(Enemy.class);
            if (RubberbandBullet != null) 
            {
                World myWorld = getWorld();// We've hit an enemy!
                Enemy e = (Enemy) getOneIntersectingObject(Enemy.class);
                e.hitMelee(1);
                e.flee();
                // MyWorld myworld= (MyWorld)myworld;
                // //Counter counter = MyWorld.getCounter();
                // counter.addScore();
                getWorld().removeObject(this);
            }
          move(speed);
          disappear();
        }
        public void direction(int s){
   if (Character.facingLeft == true)
   {
       speed = -s;
    }
    else
    {
        speed = s;
    }

    }    
    public void disappear()
    {
        timerD--;
       if(timerD == 0)
        {
            getWorld().removeObject(this);
        }
    } 
}

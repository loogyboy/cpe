import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StadiumBoss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StadiumBoss extends Scroll
{
    private final static int SWIDTH1 =800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 2500;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class Stadium.
     * 
     */
    private int scale = 5;
    //Character character;
    public StadiumBoss()
    {    
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 2400, 450, new GreenfootImage("Spanos Stadium.png"));// Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        prepare();
        worldID = 3;
    }
    public void act(){
        //cutscene3();
        setAmmoRem();
    }

    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,375,445);
        Floor floor2 = new Floor();
        addObject(floor2,909,445);
        character = new Character();
        addObject(character,69,298);
        Floor floor3 = new Floor();
        addObject(floor3,1600,445);
        
        
        
        
        health();
        GUI();
    }
    public int getID(){
        return worldID;
    }
}

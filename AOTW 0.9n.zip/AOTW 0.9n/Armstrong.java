import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Armstrong here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Armstrong extends EnemyBase
{
    public static int enemyNumber;
    public int enemiesSpawned;
    private boolean following = false;
    public boolean active = false;

    public int eSpeed;
    private int canChange;
    public boolean facingLeft = false;

    private boolean onBackStep = false;
    private int walkTimer = 0; //Times onStepBack in order to switch images at even intervals
    private int weaponID = 0; //controls weapon type, 0 is bare hands
    private double movespeed = 5;
    private int speed;
    private int gravity = 1;
    private boolean jumping;
    private int timer;
    private boolean falling;
    private boolean infront;
    private boolean inbehind;
    private int direction = 80;
    private int jumpreset;
    private boolean jumpres;

    private int stunDelay = -1;
    private int fleeTimer = -1;

    /**
     * Act - do whatever the Armstrong wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkFall();
        gravityjump();

        switchPhases();
        timerE++;
        
        Knockback();
        death();
    }

    public Armstrong()
    {

        GreenfootImage image = getImage();  
        image.scale(200, 200);
        setImage(image);
        eSpeed = 4;
        health = 20;
    }
    public int timerE = 0;
    public void switchPhases()
    {
        if( enemiesSpawned < 3 )
        {
            spawnOne();

        }
        else if( enemiesSpawned == 3 && timerE == 1000)
        {
            SpawnTwo();

        }
        else if (enemiesSpawned == 4 && timerE == 1500)
        {
            SpawnF();

        }
        else if (enemiesSpawned == 5 && timerE == 2200)
        {
            spawnE();

        }
        else if (enemiesSpawned == 6 && timerE == 2400)
        {
            spawnFR();

        }
        else if (timerE >= 2600)
        {
            attackOne();

        }

    }

    public void spawnOne()
    {
        if( Greenfoot.getRandomNumber(1000) < 20 )
        {
            Enemy enemy = new Enemy();
            World w = (World) getWorld();
            w.addObject(enemy,getX() - 2, getY());
            enemiesSpawned++;
        }
    }

    public void SpawnTwo()
    {

        Enemy enemy = new Enemy();
        World w = (World) getWorld();
        w.addObject(enemy,getX() - 2, getY());

        Enemy e = new Enemy();

        w.addObject(e,getX() - 2, getY());

        enemiesSpawned++;

    }

    public void SpawnF()
    {

        FootballEnemy f = new FootballEnemy();
        World w = (World) getWorld();
        w.addObject(f, getX() -12, getY());
        enemiesSpawned++;

    }

    public void spawnE()
    {
        Enemy enemy = new Enemy();
        World w = (World) getWorld();
        w.addObject(enemy,getX() - 8, getY()); 
        enemiesSpawned++;

    }

    public void spawnFR()
    {
        FratEnemy enemy = new FratEnemy();
        World w = (World) getWorld();
        w.addObject(enemy,getX() - 8, getY()); 
        enemiesSpawned++;
    }


    public void attackOne()
    {
        inAggroRange();
        enemyHit();
        followCharacter();

    }

    public void attackTwo()
    {

    }

    public static void addEnemyNumber()
    {
        enemyNumber++;
    }

    public void inAggroRange()
    {
        List<Character> list;
        list= getObjectsInRange(750, Character.class);
        if (list.isEmpty() == true)
        {
            following = false;
        }
        else
        {
            active = true;
            following = true;
        }
    }

    public void followCharacter()
    {
        if (kockback == false){
            if(following == true){
                if (Character.CharacterX < this.getX())
                {
                    if(onBackStep == false){
                        setImage("pres3.png");
                    }
                    if(onBackStep == true){
                        setImage("pres4.png");
                    }
                    GreenfootImage image = getImage();  
                    image.scale(200, 200);
                    facingLeft=true;
                    move(-eSpeed);
                }
                if (Character.CharacterX > this.getX())
                {
                    if(onBackStep == false){
                        setImage("pres1.png");
                    }
                    if(onBackStep == true){
                        setImage("pres2.png");
                    }
                    GreenfootImage image = getImage();  
                    image.scale(200, 200);
                    facingLeft=false;
                    move(eSpeed);
                }
                //turnTowards(Character.CharacterX, getY());
                //move(2);
            }

        }
    }

    private int hitTimer;
    public void enemyHit(){//Made by Luke
        List<Character> list;
        list= getObjectsInRange(150, Character.class);
        if (list.isEmpty() == false )
        {
            hitTimer++;
            if(hitTimer ==40)
            {
                Character hit = (Character) list.get(0);
                hit.damage(3);
                hitTimer =0;
            }
        }

    }
    /*

    int time_death = 300;
    public boolean sc = false;
    public void death()
    {
    World worlds = getWorld();

    if(dying == true)
    {
    time_death--;
    sc= true;
    if(time_death <= 0){
    isDead = true;
    worlds.removeObject(this);

    }
    }
    }
     */

}

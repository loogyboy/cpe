import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DormRoom extends Scroll
{
    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 800;
    private final static int WHeight1 = 450;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public DormRoom()
    {    
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 800, 450, new GreenfootImage("dormroomlevel.png"));
        prepare();
        worldID = 0;
    }


    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    public void act(){
        cutscene();
    }

    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);
        
        character = new Character();
        addObject(character,148,330);

        GUI();
        health();
    }

    public Character getPlayer(){
        return character;
    }

    public int getID(){
        return worldID;
    }
    private void cutscene(){
        if(character.getX() > 456){
            CS1 cs1 = new CS1();
            Greenfoot.setWorld(cs1);
        }
    }
}

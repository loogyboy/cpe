import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class Scroll here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scroll extends World
{

    public int xOffset = 0;
    private int yOffset = 0;
    public int SWIDTH;
    public int SHEIGHT;
    public static int WWIDTH;
    public int WHeight;
    public int a,b;
    public GreenfootImage bimg;
    Counter ac;
    Character character;
    private int am;
    Counter hc;
    public int worldID;
    /**
     * Constructor for objects of class DormHall.
     * 
     */
    public Scroll(int sw, int sh, int ww, int wh, int ta, int tb, GreenfootImage i) 
    {
        super(sw, sh, 1, false);
        SWIDTH = sw;
        SHEIGHT = sh;
        WWIDTH = ww;
        WHeight = wh;
        a = ta;
        b = tb;
        bimg = i;
        bimg.scale(a, b);
        //setBackground(bimg);
        shiftWorld(0,0);
    }

    private Character main;
    private GreenfootImage bkgd;
    public void act(){
        setAmmoRem();
    }

    public void shiftWorld(int dx, int dy) 
    {
        if( (xOffset + dx) <= 0 && (xOffset + dx) >= SWIDTH - WWIDTH)
        {
            xOffset = xOffset + dx;
            shiftWorldBackground(dx,0);
            shiftWorldActors(dx,0);
        }
        if ( (yOffset + dy) <= 0 && (yOffset + dy) >= SHEIGHT - WHeight)
        {
            yOffset = yOffset + dy;
            shiftWorldBackground(0,dy);
            shiftWorldActors(0,dy);
        }
    }

    private void shiftWorldBackground(int dx, int dy) {
        bkgd = new GreenfootImage(SWIDTH, SHEIGHT);
        bkgd.drawImage(bimg, xOffset, yOffset);
        setBackground(bkgd);
    }

    private void shiftWorldActors(int dx, int dy) 
    {
        List<Scrolling> saList =
            getObjects(Scrolling.class);
        for( Scrolling a : saList ) {
            a.setAbsoluteLocation(dx,dy);
        }
    }

    public static int getWWidth(){
        return WWIDTH;
    }

    public void GUI(){
        WeaponGUI weapongui = new WeaponGUI();
        addObject(weapongui,700,50);
        Counter ammocounter = new Counter();
        addObject(ammocounter, 700, 110);
        ac = ammocounter;
        am = character.getRegAmmo();
        ac.setValue(am);
    }

    public void setAmmoRem(){
        if(WeaponGUI.getShotType() == 0){
            am = character.getRegAmmo();
        }
        else if(WeaponGUI.getShotType() == 1){
            am = character.getStunAmmo();
        }
        else if(WeaponGUI.getShotType() == 2){
            am = character.getFleeAmmo();
        }
        ac.setValue(am);
    }

    public void health() 
    {
        Counter healthcounter = new Counter("Health: ");
        addObject(healthcounter,55,20);
        hc = healthcounter;
        hc.setValue(10);
    }

    public void setHealth(int health)
    {
        hc.setValue(health);
    }
    public int getID(){
        return worldID;
    }
    
}

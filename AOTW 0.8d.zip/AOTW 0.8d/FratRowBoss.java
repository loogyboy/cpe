import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FratRowBoss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratRowBoss extends Scroll
{
    private final static int SWIDTH1 = 800;
    private final static int SHEIGHT1 = 450;
    private final static int WWIDTH1 = 850;
    private final static int WHeight1 = 450;
    public boolean bossDead;
    FratBoss fratboss;
    /**
     * Constructor for objects of class FratRowBoss.
     * 
     */
    public FratRowBoss()
    {
        super(SWIDTH1, SHEIGHT1, WWIDTH1, WHeight1, 850, 450, new GreenfootImage("CS6.png"));
        //prepare();
        worldID = 1;
        prepare();
    }
    public void act(){
        //checkBoss();
        cutscene7();
        setAmmoRem();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,414,399);
        
        floor.setLocation(427,448);
        BPTable bptable = new BPTable();
        addObject(bptable,116,352);
        bptable.setLocation(144,392);

        Window window = new Window();
        addObject(window,353,271);
        window.setLocation(351,270);
        Window window2 = new Window();
        addObject(window2,563,279);
        window2.setLocation(515,271);
        Window window3 = new Window();
        addObject(window3,705,278);
        window3.setLocation(679,271);
        Window window4 = new Window();
        addObject(window4,520,382);
        window4.setLocation(513,386);
        Window window5 = new Window();
        addObject(window5,389,402);
        window4.setLocation(510,386);
        window5.setLocation(356,386);
        
        fratboss = new FratBoss();
        addObject(fratboss,0,330);
        character = new Character();
        addObject(character, 600,330);
        GUI();
        health();
    }
    private void cutscene7(){
        if(fratboss.isDead == true){
            CS7 cs7 = new CS7();
            Greenfoot.setWorld(cs7);
        }
    }   
}


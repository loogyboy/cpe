import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS8 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS8 extends World
{

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    /**
     * Constructor for objects of class CS6.
     * 
     */
    GreenfootImage bg;
    Player player;
    
    private int cstimer = 0;
    Amy amy;
    Armstrongcs armstrong;
    
    public CS8()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("Spanos Stadium.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        
         player = new Player();
        addObject(player,69,325);

        prepare();
        amy = new Amy();
        armstrong = new Armstrongcs();
    }


    public void act(){
        cstimer++;

        if(cstimer == 900){
            StadiumBoss stadiumboss = new StadiumBoss();
             Greenfoot.setWorld(stadiumboss);
            
             
        }
        if(cstimer == 50)
        {
             addObject(amy, 300, 325);
             addObject(armstrong,665,325);
             
        }
        if( cstimer == 70)
        {
            Greenfoot.playSound("Finish.wav");
            armstrong.dirChangeL();
        }
        if ( cstimer > 70 && cstimer <170)
        {
            amy.amyTalking();
        }
        if (cstimer >170 && cstimer < 440)
        {
            armstrong.move(-1);
        }
        if(cstimer == 485)
        {
            Greenfoot.playSound("bite.wav");
            armstrong.punch();
            amy.amyDeath();
        }
        if(cstimer == 540)
        {

            Greenfoot.playSound("eating.wav");
            removeObject(amy);
        }
        if(cstimer == 560)
        {
            Greenfoot.playSound("wilhelm.wav");
        }
       if(cstimer == 585)
        {
            Greenfoot.playSound("Love.wav");
        }
        if(cstimer >585 && cstimer < 765)
        {
            player.playerTalking();
        }
        if(cstimer ==765)
        {
            Greenfoot.playSound("Stop.wav");
        }
        if(cstimer >765 && cstimer < 865)
        {
            armstrong.talking();
        }
        
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Floor floor = new Floor();
        addObject(floor,437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(437,360);
        floor.setLocation(453,448);
    }
}

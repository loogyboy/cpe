import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HealthPackTwo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthPackTwo extends Powerups
{
    public HealthPackTwo(int x, int y)
    {
        super(x, y);
    }
    
    public HealthPackTwo()
    {
        super();
    }
    
    protected void checkHitCharacter()
    {
        if (!getObjectsInRange(100, Character.class).isEmpty())
        {
            Character chars = getObjectsInRange(100, Character.class).get(0);
            chars.addHealthTwo();
            getWorld().removeObject(this);
        }
    } 
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FratEnemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratEnemy extends EnemyBase
{
    /**
     * Act - do whatever the FratEnemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        followCharacter();
        throwBottle();
        checkFall();
            gravityjump();
    }    
    public void throwBottle()
    {
        if(Greenfoot.getRandomNumber(1000) <5)
        {
           Bottle b = new Bottle();
        if(facingLeft ==true)
        {
            b.setRotation(225);
            b.left();
        }
        else
        {
            b.setRotation(325);
            b.right();
        }

        getWorld().addObject(b, getX(), getY());
        }
    }
}

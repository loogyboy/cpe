import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Chair here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Chair extends Floor
{
    /**
     * Act - do whatever the Chair wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Chair(){
        GreenfootImage image = getImage();  
        image.scale(350, 200);
        setImage(image);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class FratBoss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FratBoss extends EnemyBase
{
    /**
     * Act - do whatever the FratBoss wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int canChange;
    private boolean facingLeft = false;
    /**
     * Act - do whatever the FratBoss wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public FratBoss()
    {
        GreenfootImage image = getImage();  
        image.scale(150, 250);
        setImage(image);
        health = 10;
        eSpeed = 2;
        kockback= false;
        kTimer=0;

    }
    public boolean active = false;
    int ammospeed = 10;

    public void act() 
    {
        inAggroRange();
        if(active == true){

            checkFall();
            gravityjump();
            enemyModel();
            if (stunDelay < 0)
            {
                if (fleeTimer < 0)
                {
                    followCharacter();
                    Shoot();
                }
                else
                {
                    runAway();
                    fleeTimer--;
                }
            }
            else
            {
                stunDelay--;
            }

            Knockback();
            enemyHit();
        }
        
    }    

    public void EnemyMovement()

    {
        if (facingLeft == true)
        {
            move(-eSpeed);
            if(onBackStep == false){
                setImage("FratBoss3.png");
                GreenfootImage image = getImage();  
                image.scale(125, 250);
            }
            if(onBackStep == true){
                setImage("FratBoss4.png");
                GreenfootImage image = getImage();  
                image.scale(150, 250);
            }

        }
        else
        {
            move(eSpeed);
            if(onBackStep == false){
                setImage("FratBoss1.png");
                GreenfootImage image = getImage();  
                image.scale(125, 250);
            }
            if(onBackStep == true){
                setImage("FratBoss2.png");
                GreenfootImage image = getImage();  
                image.scale(150, 250);
            }

        }
    }

    private void EnemyOrient()
    {
        canChange = canChange + 1;
        if (canChange % 60 == 0)
        {
            if (Greenfoot.getRandomNumber (9) < 4)
            { 
                TurnLeft();
            }
            else {
                TurnRight();
            }

        }
    }

    public void TurnLeft()
    {
        facingLeft = true;

    }

    public void TurnRight()
    {
        facingLeft = false;
    }

    private boolean onBackStep = false; //switches between images to control walking animation
    private int walkTimer = 0; //Times onStepBack in order to switch images at even intervals
    private int weaponID = 0; //controls weapon type, 0 is bare hands
    private double movespeed = 2;
    private int speed;
    private int gravity = 1;
    private boolean jumping;
    private int timer;
    private boolean falling;
    private boolean infront;
    private boolean inbehind;
    private int direction = 80;
    private int jumpreset;
    private boolean jumpres;
    private boolean following = false;
    private int stunDelay = -1;
    private int fleeTimer = -1;

    public void jump(){//main player jump abaility, Peter did this
        ground();
        checkFall();
        gravityjump();
        timerjump();
        actualJump();
    }

    public void timerjump(){ //determines if jump is over and if falling starts
        timer--;
        if (timer<0){
            jumping = false;
        }
        jumpreset--;
        if(jumpreset < 0){
            jumpres = false;
        }else
        {
            jumpres = true;
        }

    }

    public void actualJump(){ //checks if space is activated and not jumping currently as well as not falling
        // edited by Luke to make random base movement for enemy. Just changed key press to be a random number
        if (Greenfoot.getRandomNumber (1000) < 1 && jumping == false && falling == false && jumpres == false){
            jumping = true;
            timer = 8;
            gravity = -timer;
            falling = true;
        }
    }

    public void inAggroRange()
    {
        List<Character> list;
        list= getObjectsInRange(750, Character.class);
        if (list.isEmpty() == true)
        {
            following = false;
        }
        else
        {
            active = true;
            following = true;
        }
    }

    public void enemyModel(){ //walking animation
        walkTimer++;
        if(walkTimer < 30){
            onBackStep = false;
        }
        if(walkTimer > 30 && walkTimer < 60){
            onBackStep = true;
        }
        if(walkTimer == 60){
            walkTimer = 0;
        }
    }

    public void followCharacter()
    {
        if (kockback == false){
            if(following == true){
                if (Character.CharacterX < this.getX())
                {
                    if(onBackStep == false){
                        setImage("FratBoss3.png");
                        GreenfootImage image = getImage();  
                        image.scale(125, 250);
                    }
                    if(onBackStep == true){
                        setImage("FratBoss4.png");
                        GreenfootImage image = getImage();  
                        image.scale(150, 250);
                    }

                    facingLeft=true;
                    move(-eSpeed);
                }
                if (Character.CharacterX > this.getX())
                {
                    if(onBackStep == false){
                        setImage("FratBoss1.png");
                        GreenfootImage image = getImage();  
                        image.scale(125, 250);
                    }
                    if(onBackStep == true){
                        setImage("FratBoss2.png");
                        GreenfootImage image = getImage();  
                        image.scale(150, 250);
                    }

                    facingLeft=false;
                    move(eSpeed);
                }
                //turnTowards(Character.CharacterX, getY());
                //move(2);
            }

        }
    }

    public void runAway()
    {
        if (kockback == false){
            if(following == true){
                if (Character.CharacterX < this.getX())
                {
                    if(onBackStep == false){
                        setImage("FratBoss1.png");
                        GreenfootImage image = getImage();  
                        image.scale(125, 250);
                    }
                    if(onBackStep == true){
                        setImage("FratBoss2.png");
                        GreenfootImage image = getImage();  
                        image.scale(150, 250);
                    }

                    facingLeft=true;
                    move(eSpeed);
                }
                if (Character.CharacterX > this.getX())
                {
                    if(onBackStep == false){
                        setImage("FratBoss3.png");
                        GreenfootImage image = getImage(); 
                        image.scale(125, 250);
                    }
                    if(onBackStep == true){
                        setImage("FratBoss4.png");
                        GreenfootImage image = getImage(); 
                        image.scale(150, 250);
                    }

                    facingLeft=false;
                    move(-eSpeed);
                }

            }

        }
    }

    public void Shoot()
    {
        FratBossAmmo f = new FratBossAmmo();
        if (Greenfoot.getRandomNumber(1000) < 5){
            getWorld().addObject(f, getX(), getY());
            if(facingLeft ==true)
            {
                f.TurnLeft();

            }
            else
            {
                f.TurnRight();

            }
        }

    }

    public void stun()
    {
        stunDelay = 50;
    }

    public void flee()
    {
        fleeTimer = 75;
    }
}
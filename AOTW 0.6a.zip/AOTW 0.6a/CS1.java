import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CS1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CS1 extends World
{

    /**
     * Constructor for objects of class CS1.
     * 
     */
    GreenfootImage bg;
    Player character;
    Wowie wowie;
    Jim jim;
    private int cstimer = 0;
    public CS1()
    {    
        super(800, 450, 1);
        bg = new GreenfootImage("dormroomlevel.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }

    private void prepare()
    {
        Floor dormfloor = new Floor();
        addObject(dormfloor,376,449);

        character = new Player();
        addObject(character,456,330);

        wowie = new Wowie();
        jim = new Jim();
        
    }

    public void act(){
        cstimer++;
        if(cstimer == 1){
            Greenfoot.playSound("knock.wav");
        }
        if(cstimer == 300){
            Greenfoot.playSound("door.wav");
        }
        if(cstimer == 400){
            bg = new GreenfootImage("dormroomlevelopendoor.png");
            bg.scale(getWidth(), getHeight());
            setBackground(bg);
            addObject(wowie,699,330);
        }
        if(cstimer == 450){
            Greenfoot.playSound("zombie.wav");
        }
        if(cstimer == 500){
            addObject(jim,633,330);
        }
        if(cstimer == 550){
            Greenfoot.playSound("punch.wav");
        }
        if(cstimer == 600){
            Greenfoot.playSound("wilhelm.wav");
            removeObject(wowie);
        }
        if(cstimer > 650 && cstimer < 750){
            jim.jimTalking();
        }
    }
    
}
